import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class DA {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get hash to crack from user
        System.out.print("Enter the hash to crack: ");
        String hashToCrack = scanner.nextLine();

        // Get dictionary file path from user
        System.out.print("Enter the path to the dictionary file: ");
        String dictionaryFile = scanner.nextLine();

        try (BufferedReader br = new BufferedReader(new FileReader(dictionaryFile))) {
            String potentialPassword;
            while ((potentialPassword = br.readLine()) != null) {
                String hashedPassword = hashPassword(potentialPassword);
                if (hashToCrack.equals(hashedPassword)) {
                    System.out.println("Password found: " + potentialPassword);
                    return;
                }
            }
            System.out.println("Password not found in the dictionary.");
        } catch (IOException e) {
            System.err.println("Error reading dictionary file: " + e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error hashing password: " + e.getMessage());
        }

        scanner.close();
    }

    private static String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
