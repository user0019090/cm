import java.net.*;
import java.io.*;

class Server {
    public static void main(String a[]) {
        ServerSocket socket = null;
        DataInputStream dis = null;
        DataOutputStream dout = null;
        try {
            socket = new ServerSocket(1234);
            System.out.println("Server running...");
            while (true) {
                Socket c = socket.accept();
                dis = new DataInputStream(c.getInputStream());
                dout = new DataOutputStream(c.getOutputStream());
                String a1 = dis.readUTF();
                String s = "";
                switch (a1) {
                    case "1":
                        String str = dis.readUTF();
                        int k = dis.readInt();
                        s = encrypt(str, k);
                        break;
                    case "2":
                        String str1 = dis.readUTF();
                        int k1 = dis.readInt();
                        s = decrypt(str1, k1);
                        break;
                    default:
                        s = "Invalid option";
                        break;
                }
                dout.writeUTF(s);
                c.close();
            }

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public static String encrypt(String s, int key) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isLowerCase(ch)) {
                res.append((char) ('a' + (ch - 'a' + key) % 26));
            } else if (Character.isUpperCase(ch)) {
                res.append((char) ('A' + (ch - 'A' + key) % 26));
            } else {
                res.append(ch); // Preserve non-alphabetic characters
            }
        }
        return res.toString();
    }

    public static String decrypt(String s, int key) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isLowerCase(ch)) {
                res.append((char) ('a' + (ch - 'a' - key + 26) % 26)); // Ensure non-negative
            } else if (Character.isUpperCase(ch)) {
                res.append((char) ('A' + (ch - 'A' - key + 26) % 26)); // Ensure non-negative
            } else {
                res.append(ch); // Preserve non-alphabetic characters
            }
        }
        return res.toString();
    }
}
