import java.io.*;
import java.util.*;
import java.net.*;

class Bruteforce {
    public final static String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the cipher text:");
        String cipherText = scanner.nextLine().toLowerCase();

        String result = "";
        int key = 0;

        for (int shift = 1; shift < 26; shift++) {
            result = decrypt(cipherText, shift);
            System.out.println("Shift: " + shift + " Decrypted Text: " + result);
            System.out.print("Is this correct? (y/n): ");
            String option = scanner.nextLine();
            if (option.equalsIgnoreCase("y")) {
                key = shift;
                break;
            }
        }

        System.out.println("The decrypted word is \"" + result + "\" and the key is " + key);
        scanner.close();
    }

    public static String decrypt(String cipherText, int key) {
        StringBuilder decryptedText = new StringBuilder();
        for (int i = 0; i < cipherText.length(); i++) {
            char currentChar = cipherText.charAt(i);
            if (Character.isLetter(currentChar)) {
                int originalPos = ALPHABET.indexOf(currentChar);
                int newPos = (originalPos - key + 26) % 26;
                decryptedText.append(ALPHABET.charAt(newPos));
            } else {
                decryptedText.append(currentChar); 
            }
        }
        return decryptedText.toString();
    }
}