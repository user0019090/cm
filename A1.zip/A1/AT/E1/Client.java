import java.io.*;
import java.net.*;

class Client {
    public static void main(String a[]) {
        try {
            Socket client = new Socket("localhost", 1234);
            DataInputStream dis = new DataInputStream(client.getInputStream());
            DataOutputStream dout = new DataOutputStream(client.getOutputStream());

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("Enter a choice (1 for encrypt, 2 for decrypt): ");
            String choice = br.readLine();
            dout.writeUTF(choice);
            switch (choice) {
                case "1":
                    System.out.print("Enter a string to encrypt: ");
                    String s = br.readLine();
                    System.out.print("Enter a key: ");
                    int k1 = Integer.parseInt(br.readLine());
                    dout.writeUTF(s);
                    dout.writeInt(k1);
                    break;
                case "2":
                    System.out.print("Enter a string to decrypt: ");
                    String st = br.readLine();
                    System.out.print("Enter a key: ");
                    int k2 = Integer.parseInt(br.readLine());
                    dout.writeUTF(st);
                    dout.writeInt(k2);
                    break;
                default:
                    System.out.println("Invalid choice.");
                    client.close();
                    return;
            }

            String res = dis.readUTF();
            System.out.println("Result received from server: " + res);

            // Close resources
            dout.close();
            dis.close();
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
