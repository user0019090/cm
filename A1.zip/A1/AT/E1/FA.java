import java.util.*;

public class FA {

    private final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private final String FREQUENCY_ORDER = "etaoinshrdlcumwfgypbvkjxqz";

    public String decrypt(String cipherText, int shiftKey) {
        cipherText = cipherText.toLowerCase();
        StringBuilder plainText = new StringBuilder();
        
        for (char currentChar : cipherText.toCharArray()) {
            if (currentChar == ' ') {
                plainText.append(currentChar); 
                continue;
            }

            int charPosition = ALPHABET.indexOf(currentChar);
            int keyVal = (charPosition - shiftKey + 26) % 26;  
            plainText.append(ALPHABET.charAt(keyVal));
        }
        return plainText.toString();
    }

    public void frequencyAnalysis(String cipherText, Scanner scanner) {
        int[] freq = new int[26];
        for (char c : cipherText.toCharArray()) {
            if (c != ' ') {
                freq[ALPHABET.indexOf(c)]++;
            }
        }

        List<Character> sortedChars = new ArrayList<>();
        for (int i = 0; i < 26; i++) {
            sortedChars.add(ALPHABET.charAt(i));
        }
        sortedChars.sort((a, b) -> freq[ALPHABET.indexOf(b)] - freq[ALPHABET.indexOf(a)]);

        for (int i = 0; i < Math.min(3, sortedChars.size()); i++) {
            char mostFrequentChar = sortedChars.get(i);
            for (int j = 0; j < Math.min(3, FREQUENCY_ORDER.length()); j++) {
                char replaceChar = FREQUENCY_ORDER.charAt(j);

                int shiftKeyGuess = (ALPHABET.indexOf(mostFrequentChar) - ALPHABET.indexOf(replaceChar) + 26) % 26;
                
                String guessedPlainText = decrypt(cipherText, shiftKeyGuess);
                
                
                System.out.println("Trying shift " + shiftKeyGuess + ": " + guessedPlainText);
                
                System.out.println("Is this meaningful? (yes/no)");
                String response = scanner.next();
                
                
                if (response.equalsIgnoreCase("yes")) {
                    System.out.println("Decryption successful with key " + shiftKeyGuess + ": " + guessedPlainText);
                    return;
                }
            }
        }
        
        System.out.println("No meaningful decryption found.");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Cipher Text:");
        String cipherText = scanner.nextLine();
        
        FA fa = new FA();
        fa.frequencyAnalysis(cipherText, scanner);

        scanner.close();
    }
}
