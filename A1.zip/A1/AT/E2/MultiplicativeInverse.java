import java.util.Scanner;

public class MultiplicativeInverse {
    // Function to find the multiplicative inverse 
    public static int mulInv(int a, int b) {
        int originalB = b;
        int t1 = 0, t2 = 1;
        
        // Applying Euclidean Algorithm
        while (b != 0) {
            int q = a / b;
            int r = a % b;
            a = b;
            b = r;
            
            // Update t1 and t2 for each iteration
            int t = t1 - q * t2;
            t1 = t2;
            t2 = t;
        }
        
        // Check if a is 1, which means the inverse exists
        if (a != 1) {
            return -1; // Inverse does not exist
        }
        
        // Make sure the inverse is positive
        if (t1 < 0) {
            t1 += originalB;
        }
        
        return t1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Taking inputs from the user
        System.out.print("Enter the value of a: ");
        int a = scanner.nextInt();
        
        System.out.print("Enter the value of b: ");
        int b = scanner.nextInt();
        
        int result = mulInv(a, b);
        
        if (result == -1) {
            System.out.println("Multiplicative inverse does not exist.");
        } else {
            System.out.println("The multiplicative inverse is: " + result);
        }
        
        scanner.close();
    }
}
