import java.util.Scanner;

public class MatrixDeterminant {
    // Function to calculate the determinant of a matrix
    public static int determinant(int[][] A, int N) {
        int res;
        if (N == 1) {
            res = A[0][0];
        } else if (N == 2) {
            res = A[0][0] * A[1][1] - A[1][0] * A[0][1];
        } else {
            res = 0;
            for (int j1 = 0; j1 < N; j1++) {
                int[][] m = new int[N - 1][N - 1];
                for (int i = 1; i < N; i++) {
                    int j2 = 0;
                    for (int j = 0; j < N; j++) {
                        if (j == j1) continue;
                        m[i - 1][j2] = A[i][j];
                        j2++;
                    }
                }
                res += Math.pow(-1.0, 1.0 + j1 + 1.0) * A[0][j1] * determinant(m, N - 1);
            }
        }
        return res;
    }

    // Main method to get user input and calculate determinant
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get matrix size from user
        System.out.print("Enter the size of the matrix (N x N): ");
        int N = scanner.nextInt();
        
        // Initialize matrix
        int[][] matrix = new int[N][N];
        
        // Get matrix elements from user
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }

        // Calculate determinant
        int det = determinant(matrix, N);
        System.out.println("Determinant of the matrix is: " + det);
        
        scanner.close();
    }
}
