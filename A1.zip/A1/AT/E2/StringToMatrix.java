import java.util.Scanner;

public class StringToMatrix {
    public static int[][] strtomat(String PT, int k) {
        int length = PT.length();
        int rows = (int) Math.ceil((double) length / k);
        int[][] matrix = new int[rows][k];
        
        for (int i = 0; i < length; i++) {
            int row = i / k;
            int col = i % k;
            matrix[row][col] = PT.charAt(i);
        }
        
        return matrix;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the string: ");
        String PT = sc.nextLine();
        
        System.out.print("Enter the number of columns: ");
        int k = sc.nextInt();
        
        int[][] matrix = strtomat(PT, k);
        
        System.out.println("The matrix is:");
        for (int[] row : matrix) {
            for (int val : row) {
                System.out.print((char) val + " ");
            }
            System.out.println();
        }
    }
}
