import java.util.Scanner;

public class MatrixMultiplication {
    // Function to perform matrix multiplication
    public static int[][] matmul(int[][] a, int[][] b, int p, int q, int r, int s) {
        // Check if matrix multiplication is possible
        if (q != r) {
            throw new IllegalArgumentException("Matrix multiplication not possible. Columns of first matrix must equal rows of second matrix.");
        }
        // Initialize the result matrix
        int[][] result = new int[p][s];
        
        // Perform matrix multiplication
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < s; j++) {
                for (int k = 0; k < q; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return result;
    }
    
    // Main method for testing
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get dimensions of the first matrix
        System.out.print("Enter the number of rows in the first matrix: ");
        int p = scanner.nextInt();
        System.out.print("Enter the number of columns in the first matrix: ");
        int q = scanner.nextInt();
        int[][] a = new int[p][q];
        System.out.println("Enter the elements of the first matrix:");
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                a[i][j] = scanner.nextInt();
            }
        }
        
        // Get dimensions of the second matrix
        System.out.print("Enter the number of rows in the second matrix: ");
        int r = scanner.nextInt();
        System.out.print("Enter the number of columns in the second matrix: ");
        int s = scanner.nextInt();
        int[][] b = new int[r][s];
        System.out.println("Enter the elements of the second matrix:");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < s; j++) {
                b[i][j] = scanner.nextInt();
            }
        }
        
        // Perform matrix multiplication
        int[][] result = matmul(a, b, p, q, r, s);
        
        // Print the result matrix
        System.out.println("Result matrix:");
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result[0].length; j++) {
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
        scanner.close();
    }
}
