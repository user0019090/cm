import java.util.Scanner;

public class MatrixToString {
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of rows (p): ");
        int p = sc.nextInt();

        System.out.print("Enter number of columns (q): ");
        int q = sc.nextInt();

        int[][] matrix = new int[p][q];

        System.out.println("Enter the matrix values row by row:");
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }

        String result = mattostr(matrix, p, q);
        System.out.println("Converted String: " + result);

        sc.close();
    }

    public static String mattostr(int[][] mat, int p, int q) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < q; i++) {
            for (int j = 0; j < p; j++) {
                result.append(ALPHABET.charAt(mat[j][i]));
            }
        }
        return result.toString();
    }
}
