import java.util.Scanner;

public class ScalarMatrixMultiplication {
    public static int[][] scalmul(int[][] a, int p, int q, int detkeyinv, int m) {
        int[][] result = new int[p][q];
        
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                // Perform scalar multiplication and take modulo m
                result[i][j] = (a[i][j] * detkeyinv) % m;
                // Ensure result is non-negative
                if (result[i][j] < 0) {
                    result[i][j] += m;
                }
            }
        }
        
        return result;
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int val : row) {
                System.out.print(val + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter number of rows: ");
        int rows = sc.nextInt();
        
        System.out.print("Enter number of columns: ");
        int cols = sc.nextInt();
        
        // Input matrix elements
        int[][] matrix = new int[rows][cols];
        System.out.println("Enter matrix elements:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }
        
        System.out.print("Enter scalar value: ");
        int scalar = sc.nextInt();
        
        System.out.print("Enter modulus value: ");
        int modulus = sc.nextInt();
        
        // Perform scalar multiplication
        int[][] result = scalmul(matrix, rows, cols, scalar, modulus);
        
        System.out.println("Matrix after scalar multiplication:");
        printMatrix(result);
    }
}
