import java.util.Scanner;

public class SHA1 {

    // Constants used in SHA-1
    private static final int[] K = {
        0x5A827999, // rounds 0-19
        0x6ED9EBA1, // rounds 20-39
        0x8F1BBCDC, // rounds 40-59
        0xCA62C1D6  // rounds 60-79
    };
   
    // Left circular shift
    private static int leftRotate(int value, int bits) {
        return (value << bits) | (value >>> (32 - bits));
    }

    // Functions defined in SHA-1 (depends on round number t)
    private static int f(int t, int b, int c, int d) {
        if (t < 20) {
            return (b & c) | ((~b) & d); // f1
        } else if (t < 40) {
            return b ^ c ^ d; // f2
        } else if (t < 60) {
            return (b & c) | (b & d) | (c & d); // f3
        } else {
            return b ^ c ^ d; // f4
        }
    }

    // One step of SHA-1
    public static void sha1Step(int t, int w, int[] h) {
        // a, b, c, d, e represent h0, h1, h2, h3, h4 in SHA-1
        int a = h[0];
        int b = h[1];
        int c = h[2];
        int d = h[3];
        int e = h[4];
       
        // Perform one step of the round
        int temp = leftRotate(a, 5) + f(t, b, c, d) + e + K[t / 20] + w;
        e = d;
        d = c;
        c = leftRotate(b, 30);
        b = a;
        a = temp;
       
        // Update h0, h1, h2, h3, h4
        h[0] = a;
        h[1] = b;
        h[2] = c;
        h[3] = d;
        h[4] = e;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask the user for input (32 bits, 8 hex characters)
        System.out.println("Enter a 32-bit word (8 hex characters):");
        String inputHex = scanner.nextLine();

        // Check if input is valid (32 bits = 8 hex characters)
        if (inputHex.length() != 8) {
            System.out.println("Invalid input length! Please enter 8 hex characters.");
            return;
        }

        // Parse the input hex to a 32-bit integer
        int w = (int) Long.parseLong(inputHex, 16);

        // Initial hash values (SHA-1)
        int[] h = {0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0};

        // Perform one round of SHA-1 for a specific t (e.g., t = 10)
        int t = 10;
        sha1Step(t, w, h);

        // Display updated hash values after one step
        System.out.println("Updated hash values after one step:");
        for (int i = 0; i < h.length; i++) {
            System.out.println("h[" + i + "] = " + Integer.toHexString(h[i]));
        }

        scanner.close();
    }
}