import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Scanner;

public class RSA {
    private BigInteger n, d, e;
    private int bitlen = 1024;

    // Constructor for generating new RSA keys
    public RSA(int bits) {
        bitlen = bits;
        SecureRandom r = new SecureRandom();
        BigInteger p = new BigInteger(bitlen / 2, 100, r);
        BigInteger q = new BigInteger(bitlen / 2, 100, r);
        n = p.multiply(q);
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        e = new BigInteger("65537"); // Commonly used prime number
        d = e.modInverse(phi);
        System.out.println("Generated primes:");
        System.out.println("p: " + p);
        System.out.println("q: " + q);
        System.out.println("n: " + n);
        System.out.println("phi: " + phi);
        System.out.println("e: " + e);
        System.out.println("d: " + d);
    }

    public synchronized String encrypt(String message) {
        return (new BigInteger(message.getBytes())).modPow(e, n).toString();
    }

    public synchronized String decrypt(String message) {
        return new String((new BigInteger(message)).modPow(d, n).toByteArray());
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RSA rsa = new RSA(1024);

        // Encrypting the message
        System.out.println("Enter a message to encrypt: ");
        String plaintext = scanner.nextLine();
        String ciphertext = rsa.encrypt(plaintext);
        System.out.println("Encrypted message: " + ciphertext);

        // Decrypting the message
        System.out.println("Enter the encrypted message to decrypt:");
        String encryptedMessage = scanner.nextLine();
        String decryptedText = rsa.decrypt(encryptedMessage);
        System.out.println("Decrypted text: " + decryptedText);

        scanner.close();
    }
}
