import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Scanner;

public class DSS {
    private static SecureRandom secureRandom = new SecureRandom();

    // Generate a random prime number of specified bit length
    public static BigInteger generatePrime(int bits) {
        BigInteger primeCandidate;
        int maxAttempts = 200; // Limit the number of attempts to find a prime
        for (int i = 0; i < maxAttempts; i++) {
            primeCandidate = BigInteger.probablePrime(bits, secureRandom);
            // Ensure the number is odd and has the correct bit length
            if (primeCandidate.bitLength() == bits) {
                return primeCandidate;
            }
        }
        throw new RuntimeException("Failed to generate a prime number within the attempt limit.");
    }

    // Find the largest prime factor q of p - 1
    public static BigInteger findQ(BigInteger p) {
        BigInteger pMinusOne = p.subtract(BigInteger.ONE);
        return pMinusOne; // Using p-1 directly for this example
    }

    // Generate parameters p, q, and g for DSA
    public static Object[] gen() {
        BigInteger p = generatePrime(512 + secureRandom.nextInt(512)); // Generate a prime p with bit length between 512 and 1024
        BigInteger q = findQ(p); // Get q
        BigInteger h = new BigInteger(256, secureRandom); // Choose h
        BigInteger g = h.modPow(p.subtract(BigInteger.ONE).divide(q), p); // Calculate g
        return new Object[]{p, q, g};
    }

    // Hash the message using SHA-256
    public static BigInteger hash(String message) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(message.getBytes());
        return new BigInteger(1, hashBytes);
    }

    // Sign the message using the private key x
    public static BigInteger[] sign(BigInteger p, BigInteger q, BigInteger x, BigInteger g, String message) throws Exception {
    BigInteger k;
    do {
        k = new BigInteger(q.bitLength(), secureRandom).mod(q.subtract(BigInteger.ONE)).add(BigInteger.ONE); // Random integer k
    } while (!k.gcd(q).equals(BigInteger.ONE)); // Ensure k is coprime with q

    BigInteger r = g.modPow(k, p).mod(q); // r = (g^k mod p) mod q
    BigInteger kInv = k.modInverse(q); // k^(-1) mod q

    BigInteger h = hash(message);
    BigInteger s = (kInv.multiply(h.add(x.multiply(r)).mod(q))).mod(q); // s = k^(-1)(h + xr)

    return new BigInteger[]{s, r};
}


    public static void main(String[] args) {
        try {
            Object[] params = gen();
            BigInteger p = (BigInteger) params[0];
            BigInteger q = (BigInteger) params[1];
            BigInteger g = (BigInteger) params[2];

            System.out.println("Generated parameters:\np = " + p + "\nq = " + q + "\ng = " + g + "\n");

            BigInteger x = new BigInteger(q.bitLength(), secureRandom).mod(q.subtract(BigInteger.ONE)).add(BigInteger.ONE); // Private key
            BigInteger y = g.modPow(x, p); // Public key

            System.out.println("Private key x: " + x + "\nPublic key y: " + y + "\n");

            // Prompting user to input a message
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the message: ");
            String message = scanner.nextLine();

            BigInteger[] signature = sign(p, q, x, g, message);
            BigInteger s = signature[0];
            BigInteger r = signature[1];

            System.out.println("Signature (s, r): (" + s + ", " + r + ")");

            // Validate signature
            if (r.compareTo(BigInteger.ZERO) > 0 && r.compareTo(q) < 0 && s.compareTo(BigInteger.ZERO) > 0 && s.compareTo(q) < 0) {
                BigInteger w = s.modInverse(q); // w = s^(-1) mod q
                BigInteger u1 = (hash(message).multiply(w)).mod(q); // u1 = (h * w) mod q
                BigInteger u2 = (r.multiply(w)).mod(q); // u2 = (r * w) mod q
                BigInteger v = (g.modPow(u1, p).multiply(y.modPow(u2, p))).mod(p).mod(q); // v = (g^u1 * y^u2 mod p) mod q

                System.out.println("Computed values:\nw = " + w + "\nu1 = " + u1 + "\nu2 = " + u2 + "\nv = " + v);

                if (v.equals(r)) {
                    System.out.println("Valid signature");
                } else {
                    System.out.println("Invalid signature");
                }
            } else {
                System.out.println("Invalid signature: r or s is not in the range (0, q).");
            }

            scanner.close(); // Close the scanner after use
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
