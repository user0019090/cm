import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws Exception {
        // Set up server and accept connection
        ServerSocket serverSocket = new ServerSocket(1234);
        System.out.println("Waiting for client connection...");
        Socket socket = serverSocket.accept();
        System.out.println("Client connected.");

        // Set up input and output streams
        DataInputStream input = new DataInputStream(socket.getInputStream());
        DataOutputStream output = new DataOutputStream(socket.getOutputStream());

        // Input public parameters
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the prime number (P): ");
        BigInteger P = new BigInteger(scanner.nextLine());

        System.out.print("Enter the primitive root (G): ");
        BigInteger G = new BigInteger(scanner.nextLine());

        System.out.print("Enter the server's private key (a): ");
        BigInteger a = new BigInteger(scanner.nextLine());

        // Compute server's public key (Ga)
        BigInteger Ga = G.modPow(a, P);
        output.writeUTF(P.toString());
        output.writeUTF(G.toString());
        output.writeUTF(Ga.toString());

        // Read client's public key (Gb)
        BigInteger Gb = new BigInteger(input.readUTF());

        // Compute shared secret key
        BigInteger k = Gb.modPow(a, P);
        System.out.println("Server's public key (Ga): " + Ga);
        System.out.println("Shared secret key (k) computed by server: " + k);

        // Close resources
        input.close();
        output.close();
        socket.close();
        serverSocket.close();
    }
}
