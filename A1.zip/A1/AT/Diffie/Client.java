import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws Exception {
        // Connect to server
        Socket socket = new Socket("localhost", 1234);
        System.out.println("Connected to the server.");

        // Set up input and output streams
        DataInputStream input = new DataInputStream(socket.getInputStream());
        DataOutputStream output = new DataOutputStream(socket.getOutputStream());

        // Read public parameters from server
        BigInteger P = new BigInteger(input.readUTF());
        BigInteger G = new BigInteger(input.readUTF());
        BigInteger Ga = new BigInteger(input.readUTF());

        // Input and send client's private key (b)
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the client's private key (b): ");
        BigInteger b = new BigInteger(scanner.nextLine());

        // Compute client's public key (Gb)
        BigInteger Gb = G.modPow(b, P);
        output.writeUTF(Gb.toString());

        // Compute shared secret key
        BigInteger k = Ga.modPow(b, P);
        System.out.println("Client's public key (Gb): " + Gb);
        System.out.println("Shared secret key (k) computed by client: " + k);

        // Close resources
        input.close();
        output.close();
        socket.close();
    }
}
