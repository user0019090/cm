import java.util.*;

public class PrimitiveRoot {

    // Function to compute gcd of two numbers
    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Function to check if a number is a primitive root modulo n
    public static boolean isPrimitiveRoot(int g, int n) {
        Set<Integer> seen = new HashSet<>();
        int currentPower = 1;  // Start with g^0 % n, which is 1

        for (int i = 0; i < n - 1; i++) {
            currentPower = (currentPower * g) % n;
            if (seen.contains(currentPower)) {
                return false;  // Repeated value means it's not a primitive root
            }
            seen.add(currentPower);
        }

        return seen.size() == n - 1;
    }

    // Function to find and return a primitive root of n
    public static int findPrimitiveRoot(int n) {
        for (int g = 2; g < n; g++) {
            if (gcd(g, n) == 1 && isPrimitiveRoot(g, n)) {
                return g;  // Return the first found primitive root
            }
        }
        return -1;  // No primitive root found
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the number n
        System.out.println("Enter a number (n) to find its primitive root:");
        int n = scanner.nextInt();

        int primitiveRoot = findPrimitiveRoot(n);

        if (primitiveRoot != -1) {
            System.out.println("Primitive root of " + n + " is: " + primitiveRoot);
        } else {
            System.out.println(n + " does not have a primitive root.");
        }

        scanner.close();
    }
}
