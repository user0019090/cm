import java.util.Scanner;

public class ShiftOperations {

    // Left rotate function (circular left shift)
    public static int leftCircularShift(int value, int shift) {
        return (value << shift) | (value >>> (32 - shift));
    }

    // Right rotate function (circular right shift)
    public static int rightCircularShift(int value, int shift) {
        return (value >>> shift) | (value << (32 - shift));
    }

    // Left shift function
    public static int leftShift(int value, int shift) {
        return value << shift;
    }

    // Right shift function
    public static int rightShift(int value, int shift) {
        return value >>> shift;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get hexadecimal input from user
        System.out.print("Enter a hexadecimal number (e.g., 12345678): ");
        String hexInput = scanner.nextLine();
        int value = Integer.parseUnsignedInt(hexInput, 16);

        // Get shift amount
        System.out.print("Enter the number of bits to shift: ");
        int shift = scanner.nextInt();

        // Display menu for shift operations
        System.out.println("Choose the shift operation:");
        System.out.println("1. Left Circular Shift");
        System.out.println("2. Right Circular Shift");
        System.out.println("3. Left Shift");
        System.out.println("4. Right Shift");
        int choice = scanner.nextInt();

        int result = 0;
        switch (choice) {
            case 1:
                result = leftCircularShift(value, shift);
                System.out.printf("After left circular shift by %d bits: %08x\n", shift, result);
                break;
            case 2:
                result = rightCircularShift(value, shift);
                System.out.printf("After right circular shift by %d bits: %08x\n", shift, result);
                break;
            case 3:
                result = leftShift(value, shift);
                System.out.printf("After left shift by %d bits: %08x\n", shift, result);
                break;
            case 4:
                result = rightShift(value, shift);
                System.out.printf("After right shift by %d bits: %08x\n", shift, result);
                break;
            default:
                System.out.println("Invalid choice. Please select 1, 2, 3, or 4.");
        }

        scanner.close();
    }
}
