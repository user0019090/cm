import java.util.*;
class EllipticpEncryption {

    // Generate the affine points on the elliptic curve
    public static List<int[]> keygen(int a, int b, int p) {
        List<int[]> pt = new ArrayList<>();
        for (int i = 0; i < p; i++) {
            int R = (i * i * i + a * i + b) % p;
            if (R < 0) {
                R += p;
            }
            for (int j = 0; j < p; j++) {
                int L = (j * j) % p;
                if (L == R) {
                    pt.add(new int[]{i, j});
                }
            }
        }
        return pt;
    }

    // Scalar multiplication (k * G)
    public static int[] scalarMultiply(int[] P, int k, int a, int b, int p) {
        int[] result = null; // Identity element (point at infinity)
        int[] current = P;   // Start with the initial point P
        for (int i = 0; i < k; i++) {
            result = pointAdd(result, current, a, b, p);
        }
        return result;
    }

    // Point addition
    public static int[] pointAdd(int[] P, int[] Q, int a, int b, int p) {
        if (P == null) return Q;
        if (Q == null) return P;

        int x1 = P[0], y1 = P[1];
        int x2 = Q[0], y2 = Q[1];
        int m;

        if (P[0] == Q[0] && P[1] == Q[1]) {
            m = (3 * x1 * x1 + a) % p;
            m = mulinv(2 * y1, p) * m % p;
        } else {
            m = (y2 - y1 + p) % p;
            m = mulinv(x2 - x1 + p, p) * m % p;
        }

        if (m < 0) m += p;

        int x3 = (m * m - x1 - x2) % p;
        if (x3 < 0) x3 += p;

        int y3 = (m * (x1 - x3) - y1) % p;
        if (y3 < 0) y3 += p;

        return new int[]{x3, y3};
    }

    // Modular inverse
    public static int mulinv(int a, int b) {
        int m1 = b, m2 = a;
        int t1 = 0, t2 = 1;
        while (m2 != 0) {
            int q = m1 / m2;
            int r = m1 % m2;
            m1 = m2;
            m2 = r;
            int t = t1 - q * t2;
            t1 = t2;
            t2 = t;
        }
        if (t1 < 0) t1 += b;
        return t1;
    }

    // Convert a string to a point on the curve (basic mapping)
    public static int[] stringToPoint(String message, List<int[]> points) {
        int index = message.hashCode() % points.size();
        if (index < 0) index += points.size();
        return points.get(index);
    }

    // Encryption
    public static int[][] encrypt(String message, int[] G, int[] Pa, int k, int a, int b, int p, List<int[]> points) {
        int[] Pm = stringToPoint(message, points); // Convert message to point
        int[] C1 = scalarMultiply(G, k, a, b, p);  // C1 = kG
        int[] kPa = scalarMultiply(Pa, k, a, b, p); // kPa = k * Pa
        int[] C2 = pointAdd(Pm, kPa, a, b, p); // C2 = Pm + kPa
        return new int[][]{C1, C2};
    }

    public static void main(String[] args) {
        Scanner cls = new Scanner(System.in);

        // Input curve parameters
        System.out.println("Enter the curve parameter a:");
        int a = cls.nextInt();
        System.out.println("Enter the curve parameter b:");
        int b = cls.nextInt();
        System.out.println("Enter the prime p:");
        int p = cls.nextInt();

        // Generate affine points on the curve
        List<int[]> points = keygen(a, b, p);

        // Affine base point (G) selection
        System.out.println("Select a base point (G) index from the generated points:");
        for (int i = 0; i < points.size(); i++) {
            System.out.println(i + ": (x: " + points.get(i)[0] + ", y: " + points.get(i)[1] + ")");
        }
        int gIndex = cls.nextInt();
        int[] G = points.get(gIndex);

        // Public key selection (Pa)
        System.out.println("Enter the recipient's public key index:");
        int paIndex = cls.nextInt();
        int[] Pa = points.get(paIndex);

        // Random number k
        System.out.println("Enter a random number (k):");
        int k = cls.nextInt();

        // Message input
        System.out.println("Enter the message to encrypt:");
        String message = cls.next();

        // Encryption
        int[][] cipherText = encrypt(message, G, Pa, k, a, b, p, points);

        // Display ciphertext
        System.out.println("Ciphertext C1: (x: " + cipherText[0][0] + ", y: " + cipherText[0][1] + ")");
        System.out.println("Ciphertext C2: (x: " + cipherText[1][0] + ", y: " + cipherText[1][1] + ")");
    }
}
