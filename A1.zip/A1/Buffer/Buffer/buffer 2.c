#include <stdio.h>
#include <string.h>

void safe_function(char *input) {
    char buffer[10];  // Small buffer
    // Safely copy input to buffer, limiting the number of copied bytes
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[9] = '\0';  // Null-terminate to ensure no overflow
    printf("Buffer content: %s\n", buffer);
}

int main() {
    char input[50];
    printf("Enter some text: ");
    fgets(input, sizeof(input), stdin);  // Get input from user
    safe_function(input);  // Call safe function
    return 0;
}
