#include <stdio.h>
#include <string.h>

void vulnerable_function(char *input) {
    char buffer[10];  // Small buffer
    printf("Input: %s\n", input);
    // Buffer overflow vulnerability - no size check
    strcpy(buffer, input);  // Copies input to buffer without checking size
    printf("Buffer content: %s\n", buffer);
}

int main() {
    char input[50];
    printf("Enter some text: ");
    fgets(input, sizeof(input), stdin);  // Get input from user
    vulnerable_function(input);  // Call vulnerable function
    return 0;}
