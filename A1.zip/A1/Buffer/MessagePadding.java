import java.util.Scanner;

public class MessagePadding {

    private static byte[] padMessage(byte[] message) {
        int originalLength = message.length;
        long originalLengthBits = (long) originalLength * 8;

        // Add 1 byte for the '1' bit, and enough bytes for padding + 8 bytes for length
        int paddingLength = (56 - (originalLength + 1) % 64 + 64) % 64;
        byte[] paddedMessage = new byte[originalLength + paddingLength + 9];

        // Copy original message
        System.arraycopy(message, 0, paddedMessage, 0, originalLength);

        // Add the single '1' bit
        paddedMessage[originalLength] = (byte) 0x80;

        // Append the original length in bits as a 64-bit big-endian integer
        for (int i = 0; i < 8; i++) {
            paddedMessage[paddedMessage.length - 1 - i] = (byte) (originalLengthBits >>> (i * 8));
        }

        return paddedMessage;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the input message from the user
        System.out.print("Enter the message to be padded: ");
        String inputMessage = scanner.nextLine();

        // Convert the input message to a byte array
        byte[] messageBytes = inputMessage.getBytes();

        // Call the padMessage function
        byte[] paddedMessage = padMessage(messageBytes);

        // Display the padded message in hexadecimal format
        System.out.println("Padded Message (in hexadecimal):");
        for (byte b : paddedMessage) {
            System.out.printf("%02x ", b);
        }

        scanner.close();
    }
}
