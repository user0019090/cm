import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.Random;
import java.util.Scanner;

class Server1{
    private static final int BIT_LENGTH = 512;

    public static void main(String[] args){
        try(ServerSocket ss = new ServerSocket(5000)){
            System.out.println("Server is listening to port 5000");
            Socket s = ss.accept();
            Scanner sc = new Scanner(System.in);

            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            SecureRandom random = new SecureRandom();

            System.out.println("Enter large prime no p:");
            BigInteger p = new BigInteger(sc.nextLine());
            System.out.println("Enter the base g:");
            BigInteger g = new BigInteger(sc.nextLine());

            BigInteger ServerPrivateKey = new BigInteger(BIT_LENGTH, random);
            System.out.println("Server private key: " + ServerPrivateKey);

            BigInteger ServerPublicKey = g.modPow(ServerPrivateKey, p);
            System.out.println("Server Public Key: " + ServerPublicKey);

            dos.writeUTF(p.toString());
            dos.writeUTF(g.toString());
            dos.writeUTF(ServerPublicKey.toString());

            BigInteger ClientPublicKey = new BigInteger(dis.readUTF());

            BigInteger SharedKey = ClientPublicKey.modPow(ServerPrivateKey, p);
            System.out.println("Shared Key: " + SharedKey);


        }catch(Exception e){}
    }
}