public class LeftCircularShift {

    // Left rotate function (circular left shift)
    public static int leftRotate(int value, int shift) {
        // Perform the circular shift: shift left, then shift right to complete the circular effect
        return (value << shift) | (value >>> (32 - shift));
    }

    public static void main(String[] args) {
        int value = 0x12345678; // Sample input value
        int shift = 5;          // Number of bits to shift left

        // Call the left circular shift function
        int result = leftRotate(value, shift);

        // Output the original value and the result after circular left shift
        System.out.printf("Original value: %08x\n", value);
        System.out.printf("After left circular shift by %d bits: %08x\n", shift, result);
    }
}
