import java.util.*;
class KeyExchange {
 // Generate the affine points on the elliptic curve
 public static List<int[]> keygen(int a, int b, int p) {
 List<int[]> points = new ArrayList<>();
 for (int i = 0; i < p; i++) {
 int R = (i * i * i + a * i + b) % p;
 if (R < 0) {
 R += p;
 }
 for (int j = 0; j < p; j++) {
 int L = (j * j) % p;
 if (L == R) {
 points.add(new int[]{i, j});
 }
 }
 }
 return points;
 }
 // Scalar multiplication (n * G)
 public static int[] scalarMultiply(int[] P, int n, int a, int b, int p) {
 int[] result = null; // Point at infinity
 int[] current = P; // Start with the base point G
 for (int i = 0; i < n; i++) {
 result = pointAdd(result, current, a, b, p);
 }
 return result;
 }
 // Point addition
 public static int[] pointAdd(int[] P, int[] Q, int a, int b, int p) {
 if (P == null) return Q;
 if (Q == null) return P;
 int x1 = P[0], y1 = P[1];
 int x2 = Q[0], y2 = Q[1];
 int m;
 if (P[0] == Q[0] && P[1] == Q[1]) {
 m = (3 * x1 * x1 + a) % p;
 m = mulinv(2 * y1, p) * m % p;
 } else {

 m = (y2 - y1 + p) % p;
 m = mulinv(x2 - x1 + p, p) * m % p;
 }
 if (m < 0) m += p;
 int x3 = (m * m - x1 - x2) % p;
 if (x3 < 0) x3 += p;
 int y3 = (m * (x1 - x3) - y1) % p;
 if (y3 < 0) y3 += p;
 return new int[]{x3, y3};
 }
 // Modular inverse
 public static int mulinv(int a, int b) {
 int m1 = b, m2 = a;
 int t1 = 0, t2 = 1;
 while (m2 != 0) {
 int q = m1 / m2;
 int r = m1 % m2;
 m1 = m2;
 m2 = r;
 int t = t1 - q * t2;
 t1 = t2;
 t2 = t;
 }
 if (t1 < 0) t1 += b;
 return t1;
 }
 public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
 // Step 1: Define the elliptic curve parameters
 System.out.println("Enter the curve parameter a:");

 int a = scanner.nextInt();
 System.out.println("Enter the curve parameter b:");
 int b = scanner.nextInt();
 System.out.println("Enter the prime p:");
 int p = scanner.nextInt();
 // Generate points on the curve
 List<int[]> points = keygen(a, b, p);
 // Step 2: Select a base point G
 System.out.println("Select a base point (G) index from the generated points:");
 for (int i = 0; i < points.size(); i++) {
 System.out.println(i + ": (x: " + points.get(i)[0] + ", y: " + points.get(i)[1] + ")");
 }
 int gIndex = scanner.nextInt();
 int[] G = points.get(gIndex);
 // ---------------- User A -----------------
 System.out.println("User A: Enter your private key (nA):");
 int nA = scanner.nextInt();
 // Compute public key PA = nA * G
 int[] PA = scalarMultiply(G, nA, a, b, p);
 System.out.println("User A's public key (PA): (x: " + PA[0] + ", y: " + PA[1] + ")");
 // ---------------- User B -----------------
 System.out.println("User B: Enter your private key (nB):");
 int nB = scanner.nextInt();
 // Compute public key PB = nB * G
 int[] PB = scalarMultiply(G, nB, a, b, p);
 System.out.println("User B's public key (PB): (x: " + PB[0] + ", y: " + PB[1] + ")");
 // ---------------- Key Computation -----------------
 // User A receives PB from User B and computes shared key K = nA * PB
 int[] sharedKeyA = scalarMultiply(PB, nA, a, b, p);

 System.out.println("User A's computed shared key (K): (x: " + sharedKeyA[0] + ", y: " + 
sharedKeyA[1] + ")");
 // User B receives PA from User A and computes shared key K = nB * PA
 int[] sharedKeyB = scalarMultiply(PA, nB, a, b, p);
 System.out.println("User B's computed shared key (K): (x: " + sharedKeyB[0] + ", y: " + 
sharedKeyB[1] + ")");
 // Verify if both keys match
 if (sharedKeyA[0] == sharedKeyB[0] && sharedKeyA[1] == sharedKeyB[1]) {
 System.out.println("Key exchange successful, both users share the same key.");
 } else {
 System.out.println("Key exchange failed, keys do not match.");
 }
 }
}
