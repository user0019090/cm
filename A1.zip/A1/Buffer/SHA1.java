import java.util.Scanner;

public class SHA1 {

    // Constants for SHA-1
    private static final int H0 = 0x67452301;
    private static final int H1 = 0xEFCDAB89;
    private static final int H2 = 0x98BADCFE;
    private static final int H3 = 0x10325476;
    private static final int H4 = 0xC3D2E1F0;

    // Left rotate function (circular left shift)
    private static int leftRotate(int value, int shift) {
        return (value << shift) | (value >>> (32 - shift));
    }

    // Function to pad the input message to a multiple of 512 bits
    private static byte[] padMessage(byte[] message) {
        int originalLength = message.length;
        long originalLengthBits = (long) originalLength * 8;

        // Add 1 byte for the '1' bit, and enough bytes for padding + 8 bytes for length
        int paddingLength = (56 - (originalLength + 1) % 64 + 64) % 64;
        byte[] paddedMessage = new byte[originalLength + paddingLength + 9];

        // Copy original message
        System.arraycopy(message, 0, paddedMessage, 0, originalLength);

        // Add the single '1' bit
        paddedMessage[originalLength] = (byte) 0x80;

        // Append the original length in bits as a 64-bit big-endian integer
        for (int i = 0; i < 8; i++) {
            paddedMessage[paddedMessage.length - 1 - i] = (byte) (originalLengthBits >>> (i * 8));
        }

        return paddedMessage;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get input text from the user
        System.out.print("Enter the text to hash: ");
        String inputText = scanner.nextLine();

        // Pad the input message
        byte[] paddedMessage = padMessage(inputText.getBytes());

        // Ask for round number and step number
        System.out.print("Enter the round number (0-79): ");
        int round = scanner.nextInt();
        System.out.print("Enter the step number (0-15): ");
        int step = scanner.nextInt();

        // Ensure valid round and step numbers
        if (round < 0 || round > 79 || step < 0 || step > 15) {
            System.out.println("Invalid round or step number. Please enter valid values.");
            return;
        }

        // Message schedule array
        int[] w = new int[80];

        // Process block for the first 16 steps
        for (int i = 0; i < 16; i++) {
            w[i] = ((paddedMessage[i * 4] & 0xFF) << 24) | ((paddedMessage[i * 4 + 1] & 0xFF) << 16)
                    | ((paddedMessage[i * 4 + 2] & 0xFF) << 8) | (paddedMessage[i * 4 + 3] & 0xFF);
        }

        // Extend the sixteen 32-bit words into eighty 32-bit words
        for (int i = 16; i < 80; i++) {
            w[i] = leftRotate(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1); // Added closing parenthesis
        }

        // Initial hash values
        int a = H0, b = H1, c = H2, d = H3, e = H4;

        // Determine the value of f and k based on the round number
        int f, k;
        if (round < 20) {
            f = (b & c) | (~b & d);  // First 20 rounds
            k = 0x5A827999;
        } else if (round < 40) {
            f = b ^ c ^ d;           // 20 to 39 rounds
            k = 0x6ED9EBA1;
        } else if (round < 60) {
            f = (b & c) | (b & d) | (c & d);  // 40 to 59 rounds
            k = 0x8F1BBCDC;
        } else {
            f = b ^ c ^ d;           // 60 to 79 rounds
            k = 0xCA62C1D6;
        }

        // Perform the specific step (for the given step in the block)
        int temp = leftRotate(a, 5) + f + e + k + w[step];
        e = d;
        d = c;
        c = leftRotate(b, 30);
        b = a;
        a = temp;

        // Output the updated hash values after the specific step
        System.out.printf("After round %d and step %d:\n a = %08x\n b = %08x\n c = %08x\n d = %08x\n e = %08x\n",
                round, step, a, b, c, d, e);
    }
}
