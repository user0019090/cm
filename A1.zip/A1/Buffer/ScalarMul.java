import java.util.*;

public class ScalarMul {

    // Scalar multiplication (k * G)
    public static int[] scalarMultiply(int[] P, int k, int a, int b, int p) {
        int[] result = null;  // Identity element (point at infinity)
        int[] current = P;    // Start with the initial point P
        for (int i = 0; i < k; i++) {
            result = pointAdd(result, current, a, b, p);
        }
        return result;
    }

    // Point addition logic
    public static int[] pointAdd(int[] P, int[] Q, int a, int b, int p) {
        if (P == null) return Q;  // If P is the point at infinity
        if (Q == null) return P;  // If Q is the point at infinity

        int x1 = P[0], y1 = P[1];
        int x2 = Q[0], y2 = Q[1];
        int m;

        if (x1 == x2 && y1 == y2) {  // Point doubling case
            m = (3 * x1 * x1 + a) % p;
            m = mulinv(2 * y1, p) * m % p;
        } else {  // Point addition case
            m = (y2 - y1 + p) % p;
            m = mulinv(x2 - x1 + p, p) * m % p;
        }

        if (m < 0) m += p;

        int x3 = (m * m - x1 - x2) % p;
        if (x3 < 0) x3 += p;

        int y3 = (m * (x1 - x3) - y1) % p;
        if (y3 < 0) y3 += p;

        return new int[]{x3, y3};
    }

    // Modular inverse (for division in modular arithmetic)
    public static int mulinv(int a, int p) {
        int m1 = p, m2 = a;
        int t1 = 0, t2 = 1;
        while (m2 != 0) {
            int q = m1 / m2;
            int r = m1 % m2;
            m1 = m2;
            m2 = r;
            int t = t1 - q * t2;
            t1 = t2;
            t2 = t;
        }
        if (t1 < 0) t1 += p;
        return t1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input curve parameters
        System.out.println("Enter the curve parameter a:");
        int a = scanner.nextInt();
        System.out.println("Enter the curve parameter b:");
        int b = scanner.nextInt();
        System.out.println("Enter the prime p:");
        int p = scanner.nextInt();

        // Input a base point
        System.out.println("Enter the base point (G) x coordinate:");
        int Gx = scanner.nextInt();
        System.out.println("Enter the base point (G) y coordinate:");
        int Gy = scanner.nextInt();
        int[] G = new int[]{Gx, Gy};

        // Input scalar k for multiplication
        System.out.println("Enter the scalar value (k):");
        int k = scanner.nextInt();

        // Perform scalar multiplication
        int[] result = scalarMultiply(G, k, a, b, p);

        // Display result
        System.out.println("Result after scalar multiplication:");
        System.out.println("x: " + result[0] + ", y: " + result[1]);

        scanner.close();
    }
}
