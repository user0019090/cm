import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StringToPoint {

    // Converts a string message to a point from the list of points
    public static int[] stringToPoint(String message, List<int[]> points) {
        int index = message.hashCode() % points.size();
        if (index < 0) index += points.size();  // Ensure the index is non-negative
        return points.get(index);               // Return the point from the list
    }

    // Simple point generator (for demonstration purposes)
    public static List<int[]> generateDummyPoints(int numPoints) {
        List<int[]> points = new ArrayList<>();
        for (int i = 0; i < numPoints; i++) {
            points.add(new int[]{i, (i * i) % numPoints});  // Dummy points as (x, y)
        }
        return points;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Generate a list of dummy points
        List<int[]> points = generateDummyPoints(10);

        // Display the generated points
        System.out.println("Generated Points:");
        for (int i = 0; i < points.size(); i++) {
            System.out.println("Point " + i + ": (x = " + points.get(i)[0] + ", y = " + points.get(i)[1] + ")");
        }

        // Input the message to be converted to a point
        System.out.println("Enter the message to map to a point:");
        String message = scanner.nextLine();

        // Convert the message to a point on the curve
        int[] point = stringToPoint(message, points);

        // Display the corresponding point
        System.out.println("The message '" + message + "' is mapped to the point: (x = " + point[0] + ", y = " + point[1] + ")");
        
        scanner.close();
    }
}
