import java.net.*;
import java.io.*;
import java.math.BigInteger;
import java.security.SecureRandom;

public class MITMProxy {
    private static final int BIT_LENGTH = 512;

    public static void main(String[] args) {
        try (ServerSocket mitmSocket = new ServerSocket(6000)) {
            System.out.println("MITM is listening on port 6000...");

            // MITM accepts connection from the client
            Socket clientSocket = mitmSocket.accept();
            DataInputStream clientInput = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream clientOutput = new DataOutputStream(clientSocket.getOutputStream());

            // MITM connects to the server
            Socket serverSocket = new Socket("localhost", 5000);
            DataInputStream serverInput = new DataInputStream(serverSocket.getInputStream());
            DataOutputStream serverOutput = new DataOutputStream(serverSocket.getOutputStream());

            // Intercept public parameters from the server
            BigInteger p = new BigInteger(serverInput.readUTF());
            BigInteger g = new BigInteger(serverInput.readUTF());
            BigInteger serverPublicKey = new BigInteger(serverInput.readUTF());

            // Send p and g to the client
            clientOutput.writeUTF(p.toString());
            clientOutput.writeUTF(g.toString());

            // MITM generates its own private key and computes public key
            SecureRandom random = new SecureRandom();
            BigInteger mitmPrivateKey = new BigInteger(BIT_LENGTH, random);
            BigInteger mitmPublicKey = g.modPow(mitmPrivateKey, p);

            // Send MITM's public key to the client (pretending to be the server)
            clientOutput.writeUTF(mitmPublicKey.toString());

            // Receive the client's public key
            BigInteger clientPublicKey = new BigInteger(clientInput.readUTF());

            // Send MITM's public key to the server (pretending to be the client)
            serverOutput.writeUTF(mitmPublicKey.toString());

            // Compute the shared secret with the client
            BigInteger sharedSecretClient = clientPublicKey.modPow(mitmPrivateKey, p);
            System.out.println("MITM Shared Secret with Client: " + sharedSecretClient);

            // Compute the shared secret with the server
            BigInteger sharedSecretServer = serverPublicKey.modPow(mitmPrivateKey, p);
            System.out.println("MITM Shared Secret with Server: " + sharedSecretServer);

            // At this point, the MITM can decrypt messages between the client and server

            // Close connections
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}