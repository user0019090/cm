import java.io.*;
import java.util.*;
import java.math.BigInteger;
import java.security.*;
import java.net.*;

public class Client1{
    private static final int BIT_LENGTH = 512;

    public static void main(String[] args){
        try(Socket s = new Socket("localhost",6000)){
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            Scanner sc = new Scanner(System.in);
            SecureRandom random = new SecureRandom();

            BigInteger p = new BigInteger(dis.readUTF());
            BigInteger g = new BigInteger(dis.readUTF());
            BigInteger ServerPublicKey = new BigInteger(dis.readUTF());
            
            BigInteger ClientPrivateKey = new BigInteger(BIT_LENGTH,random);
            System.out.println("Client Private Key: " + ClientPrivateKey);

            BigInteger ClientPublicKey = g.modPow(ClientPrivateKey,p);
            System.out.println("Client Public Key: " + ClientPublicKey);

            dos.writeUTF(ClientPublicKey.toString());

            BigInteger SharedKey = ServerPublicKey.modPow(ClientPrivateKey,p);
            System.out.println("Shared Key: " + SharedKey);
             
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}