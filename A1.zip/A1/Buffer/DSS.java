import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.math.BigInteger;

class DSS {
    private static int p = -1, q = -1, g = -1, y = -1, x = -1, h = -1;
    private static Scanner sc = new Scanner(System.in);

    public static String hashMessage(String message) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(message.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println("SHA-256 algorithm not found!");
            return null;
        }
    }

    public static List<Integer> primeFactors(int n) {
        List<Integer> factors = new ArrayList<>();
        for (int i = 2; i < n; i++) {
            if (((n - 1) % i == 0) && (isPrime(i))) {
                factors.add(i);
            }
        }
        return factors;
    }

    static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    static int[] digitalSignature(int p, int q, int g, String hm, int x) {
        System.out.println("Select random value less than " + q);
        int k = sc.nextInt();
        BigInteger hashValue = new BigInteger(hm, 16);
        BigInteger gPowerK = BigInteger.valueOf(g).modPow(BigInteger.valueOf(k), BigInteger.valueOf(p));
        BigInteger r = gPowerK.mod(BigInteger.valueOf(q));
        int ki = multiplicativeInverse(k, q);
        BigInteger xR = BigInteger.valueOf(x).multiply(r);
        BigInteger val = hashValue.add(xR);
        BigInteger kmul = (BigInteger.valueOf(ki)).multiply(val);
        BigInteger s = kmul.mod(BigInteger.valueOf(q));
        System.out.println("r:" + r);
        System.out.println("s:" + s);
        return new int[]{r.intValue(), s.intValue()};
    }

    static int multiplicativeInverse(int a, int b) {
        int div = b;
        if (a < b) {
            div = b;
            int temp = b;
            b = a;
            a = temp;
        }
        int m = 1;
        int quotient, remainder, t1 = 0, t2 = 1, t;

        while (m != 0) {
            quotient = a / b;
            remainder = a % b;
            t = (t1 - (quotient * t2));

            a = b;
            b = remainder;
            t1 = t2;
            t2 = t;
            if ((a == 1) && (b == 0)) {
                if (t1 > 0) {
                    return t1;
                } else {
                    t1 = (t1 + div) % div;
                    return t1;
                }
            }
            if ((a != 0) && (b == 0)) {
                m = 0;
            }
        }
        return -1;
    }

    static int keyGeneration() {
        System.out.println("Enter prime number p:");
        p = sc.nextInt();
        List<Integer> list = primeFactors(p);
        System.out.println("Prime factors of (p-1) are: " + list);

        System.out.println("Select one prime factor as q:");
        q = sc.nextInt();

        System.out.println("Select value for h (1 to " + (p - 1) + "):");
        h = sc.nextInt();
        if (h <= 1 || h >= p) {
            System.out.println("Invalid value for h.");
            return -1;
        }
        g = (int) (Math.pow(h, ((p - 1) / q))) % p;
        System.out.println("Value of g: " + g);

        System.out.println("Enter private key x:");
        x = sc.nextInt();
        y = (int) (Math.pow(g, x) % p);
        System.out.println("Public key y: " + y);

        return y;
    }

    public static String readFileAsString(String filePath) throws IOException {
        return new String(Files.readAllBytes(Paths.get(filePath)));
    }

    static boolean Verification() {
        try{
        System.out.print("Enter file path that needs verification:");
        String filePaths = sc.nextLine();
        String messagee = readFileAsString(filePaths);
        String hashMsg = hashMessage(messagee);
        System.out.println("Enter r:");
        BigInteger rr = sc.nextBigInteger();
        System.out.println("Enter s:");
        BigInteger ss = sc.nextBigInteger();
        System.out.print("Enter p:");
        BigInteger pp = sc.nextBigInteger();
        System.out.println("Enter q:");
        BigInteger qq = sc.nextBigInteger();
        System.out.println("Enter g:");
        BigInteger gg = sc.nextBigInteger();
        System.out.println("Enter public key of sender:");
        BigInteger yy = sc.nextBigInteger();
        int sinverse = multiplicativeInverse(ss.intValue(), qq.intValue());
        BigInteger w = BigInteger.valueOf(sinverse).mod(qq);
        BigInteger hash = new BigInteger(hashMsg, 16);
        BigInteger u1 = (hash.multiply(w)).mod(qq);
        BigInteger u2 = (rr.multiply(w)).mod(qq);
        BigInteger gu1 = (gg).pow(u1.intValue()).mod(pp);
        BigInteger gu2 = (yy).pow(u2.intValue()).mod(pp);
        BigInteger v = (gu1.multiply(gu2)).mod(pp).mod(qq);

        // Use equals method for BigInteger comparison
        if (v.equals(rr)) {
            return true;
        }
       
    }
    catch(Exception e)
    {
        System.out.println("exception:"+e);
    }
    return false;
    }

    public static void main(String[] args) {
        try {
            System.out.println("Enter 1 for Key Generation and Signature Generation \nEnter 2 for digital signature verification:");
            int i=sc.nextInt();
            sc.nextLine();
            if (i==1){
            System.out.println("1. Key Generation");
            System.out.println("Enter file path:");
            String filePath = sc.nextLine();
            String message = readFileAsString(filePath);
            String hashMessage = hashMessage(message);
            System.out.println("Hashed Message: " + hashMessage);
            System.out.println("2. Signature Generation");
            int publicKey = keyGeneration();
            System.out.println("Generating Digital Signature...");
            int[] signature = digitalSignature(p, q, g, hashMessage, x);
            System.out.println("Digital Signature: r = " + signature[0] + ", s = " + signature[1]);
        }
        else if (i==2){
            System.out.println("3. Verification:");
            boolean vak = Verification();
            System.out.println("Verification status: " + vak);
        }
        else
        {
            System.out.println("invalid");
        }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
