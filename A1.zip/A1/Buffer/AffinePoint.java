import java.util.*;

public class AffinePoint {

    // Generate the affine points on the elliptic curve
    public static List<int[]> keygen(int a, int b, int p) {
        List<int[]> points = new ArrayList<>();
        for (int i = 0; i < p; i++) {
            int R = (i * i * i + a * i + b) % p;
            if (R < 0) R += p;  // Adjust negative modulo result
            for (int j = 0; j < p; j++) {
                int L = (j * j) % p;
                if (L == R) {
                    points.add(new int[]{i, j});
                }
            }
        }
        return points;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input curve parameters
        System.out.println("Enter the curve parameter a:");
        int a = scanner.nextInt();
        System.out.println("Enter the curve parameter b:");
        int b = scanner.nextInt();
        System.out.println("Enter the prime p:");
        int p = scanner.nextInt();

        // Generate affine points on the curve
        List<int[]> points = keygen(a, b, p);

        // Display affine points
        System.out.println("Generated affine points:");
        for (int i = 0; i < points.size(); i++) {
            System.out.println(i + ": (x: " + points.get(i)[0] + ", y: " + points.get(i)[1] + ")");
        }

        scanner.close();
    }
}
