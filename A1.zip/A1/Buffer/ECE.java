import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ECE {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get curve parameters from the user
        System.out.println("Enter value for prime p:");
        BigInteger p = scanner.nextBigInteger();
        System.out.println("Enter value for a:");
        BigInteger a = scanner.nextBigInteger();
        System.out.println("Enter value for b:");
        BigInteger b = scanner.nextBigInteger();

        // List to store all affine points
        List<BigInteger[]> affinePoints = new ArrayList<>();

        // Loop over all possible values of x (from 0 to p-1)
        for (BigInteger x = BigInteger.ZERO; x.compareTo(p) < 0; x = x.add(BigInteger.ONE)) {
            // Calculate the right-hand side: (x^3 + ax + b) mod p
            BigInteger rhs = x.pow(3).add(a.multiply(x)).add(b).mod(p);

            // Find all y such that y^2 ≡ rhs (mod p)
            for (BigInteger y = BigInteger.ZERO; y.compareTo(p) < 0; y = y.add(BigInteger.ONE)) {
                if (y.pow(2).mod(p).equals(rhs)) {
                    // If y^2 ≡ rhs (mod p), then (x, y) is an affine point
                    affinePoints.add(new BigInteger[]{x, y});
                    System.out.println("Affine point: (" + x + ", " + y + ")");
                }
            }
        }

        // If no points were found, notify the user
        if (affinePoints.isEmpty()) {
            System.out.println("No affine points found on the curve.");
            return;
        }

        // Ask user to select one affine point
        System.out.println("Select one affine point (enter index):");
        for (int i = 0; i < affinePoints.size(); i++) {
            BigInteger[] point = affinePoints.get(i);
            System.out.println(i + ": (" + point[0] + ", " + point[1] + ")");
        }
        int selectedIndex = scanner.nextInt();
        if (selectedIndex < 0 || selectedIndex >= affinePoints.size()) {
            System.out.println("Invalid index selected.");
            return;
        }

        BigInteger selectedX = affinePoints.get(selectedIndex)[0];
        BigInteger selectedY = affinePoints.get(selectedIndex)[1];
        System.out.println("You selected: (" + selectedX + ", " + selectedY + ")");

        // Get private key from the user
        System.out.println("Enter private key (integer value):");
        BigInteger privateKey = scanner.nextBigInteger();

        // Perform scalar multiplication using double-and-add
        BigInteger[] result = scalarMultiply(selectedX, selectedY, a, p, privateKey);

        // Print the result of the scalar multiplication
        if (result != null) {
            System.out.println("Result after multiplying private key with (x, y):");
            System.out.println("New x = " + result[0]);
            System.out.println("New y = " + result[1]);
        } else {
            System.out.println("Result is point at infinity.");
        }
    }

    // Elliptic curve point doubling
    public static BigInteger[] pointDouble(BigInteger x, BigInteger y, BigInteger a, BigInteger p) {
        BigInteger slope = (x.pow(2).multiply(BigInteger.valueOf(3)).add(a))
                .multiply(y.multiply(BigInteger.valueOf(2)).modInverse(p)).mod(p);
        BigInteger xr = slope.pow(2).subtract(x.multiply(BigInteger.valueOf(2))).mod(p);
        BigInteger yr = slope.multiply(x.subtract(xr)).subtract(y).mod(p);
        return new BigInteger[]{xr, yr};
    }

    // Elliptic curve point addition
    public static BigInteger[] pointAdd(BigInteger x1, BigInteger y1, BigInteger x2, BigInteger y2, BigInteger p) {
        if (x1.equals(x2) && y1.equals(y2)) {
            return pointDouble(x1, y1, x1, p); // use point doubling when points are the same
        }
        BigInteger slope = (y2.subtract(y1)).multiply(x2.subtract(x1).modInverse(p)).mod(p);
        BigInteger xr = slope.pow(2).subtract(x1).subtract(x2).mod(p);
        BigInteger yr = slope.multiply(x1.subtract(xr)).subtract(y1).mod(p);
        return new BigInteger[]{xr, yr};
    }

    // Scalar multiplication using double-and-add algorithm
    public static BigInteger[] scalarMultiply(BigInteger x, BigInteger y, BigInteger a, BigInteger p, BigInteger k) {
        BigInteger[] result = null; // Point at infinity (neutral element)
        BigInteger[] addend = new BigInteger[]{x, y}; // Initialize to the input point (x, y)

        // Loop through each bit of the scalar k
        while (k.compareTo(BigInteger.ZERO) > 0) {
            if (k.testBit(0)) {
                // Add addend to the result if the corresponding bit of k is 1
                if (result == null) {
                    result = addend; // Initialize result to the first addend
                } else {
                    result = pointAdd(result[0], result[1], addend[0], addend[1], p);
                }
            }
            // Double the point addend
            addend = pointDouble(addend[0], addend[1], a, p);
            k = k.shiftRight(1); // Move to the next bit
        }
        return result;
    }
}
