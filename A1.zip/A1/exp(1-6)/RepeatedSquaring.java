import java.math.BigInteger;
import java.util.Scanner;

public class RepeatedSquaring {

    // Method to compute (a^b) % m using repeated squaring
    static BigInteger repeatedSquaring(BigInteger a, BigInteger b, BigInteger m) {
        BigInteger res = BigInteger.ONE; // Initialize result as 1
        a = a.mod(m); // Update 'a' to be within the modulus

        while (b.compareTo(BigInteger.ZERO) > 0) {
            if (b.mod(BigInteger.valueOf(2)).equals(BigInteger.ONE)) {
                res = res.multiply(a).mod(m); // Multiply and mod if b is odd
            }
            a = a.multiply(a).mod(m); // Square 'a'
            b = b.divide(BigInteger.valueOf(2)); // Divide b by 2
        }
        return res;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input base 'a'
        System.out.print("Enter the base (a): ");
        BigInteger a = new BigInteger(scanner.nextLine());

        // Input exponent 'b'
        System.out.print("Enter the exponent (b): ");
        BigInteger b = new BigInteger(scanner.nextLine());

        // Input modulus 'm'
        System.out.print("Enter the modulus (m): ");
        BigInteger m = new BigInteger(scanner.nextLine());

        // Call the repeated squaring method
        BigInteger result = repeatedSquaring(a, b, m);

        // Display the result
        System.out.println("Result of (a^b) % m: " + result);

        scanner.close();
    }
}
