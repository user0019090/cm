def caesar_cipher_encrypt(plaintext, shift):
    ciphertext = ""
    for char in plaintext:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            shifted_char = chr((ord(char) - shift_base + shift) % 26 + shift_base)
            ciphertext += shifted_char
        else:
            ciphertext += char
    return ciphertext

# Get user input
plaintext = input("Enter the text you want to encrypt: ")
shift = int(input("Enter the shift key (number): "))

# Encrypt the plaintext
ciphertext = caesar_cipher_encrypt(plaintext, shift)

# Output the ciphertext
print("Ciphertext:", ciphertext)
