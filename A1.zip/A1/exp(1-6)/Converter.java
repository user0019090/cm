import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Converter {
    private int[] dictionary;
    private char[] alphaList;
    private int m;

    public Converter(int[] dictionary, char[] alphaList, int m) {
        this.dictionary = dictionary;
        this.alphaList = alphaList;
        this.m = m;
    }

    public List<List<Integer>> convertStrMat(String word, int syllabel) {
        List<List<Integer>> result = new ArrayList<>();
        while (word.length() % syllabel != 0) {
            word += 'X';
        }
        System.out.println(word);
        List<String> sequences = new ArrayList<>();
        for (int i = 0; i < word.length(); i += syllabel) {
            sequences.add(word.substring(i, i + syllabel));
        }
        for (String seq : sequences) {
            List<Integer> tempList = new ArrayList<>();
            for (char ch : seq.toCharArray()) {
                tempList.add(dictionary[ch - 'A']); // Assuming 'A' as the base for indexing
            }
            result.add(tempList);
        }
        List<List<Integer>> newResult = new ArrayList<>();
        for (int i = 0; i < result.get(0).size(); i++) {
            List<Integer> tempList = new ArrayList<>();
            for (List<Integer> integers : result) {
                tempList.add(integers.get(i));
            }
            newResult.add(tempList);
        }
        return newResult;
    }

    public String convertMatStr(int[][] mat) {
        char[][] result = new char[mat.length][mat[0].length];
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                result[i][j] = alphaList[mat[i][j] % m];
            }
        }
        for (char[] row : result) {
            System.out.println(Arrays.toString(row));
        }
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < result[0].length; i++) {
            for (char[] chars : result) {
                text.append(chars[i]);
            }
        }
        return text.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Example dictionary and alphaList
        int[] dictionary = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
        char[] alphaList = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        int m = 26;

        Converter converter = new Converter(dictionary, alphaList, m);

        // Get input for convertStrMat
        System.out.print("Enter a word: ");
        String word = scanner.nextLine();
        System.out.print("Enter the syllable length: ");
        int syllabel = scanner.nextInt();

        List<List<Integer>> convertedMat = converter.convertStrMat(word, syllabel);
        System.out.println("Converted Matrix: " + convertedMat);

        // Get input for convertMatStr
        System.out.print("Enter the number of rows in the matrix: ");
        int rows = scanner.nextInt();
        System.out.print("Enter the number of columns in the matrix: ");
        int cols = scanner.nextInt();

        int[][] mat = new int[rows][cols];
        System.out.println("Enter the matrix values row by row:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                mat[i][j] = scanner.nextInt();
            }
        }

        String convertedStr = converter.convertMatStr(mat);
        System.out.println("Converted String: " + convertedStr);

        scanner.close();
    }
}

