import java.util.*;

public class FrequencySort {
    public static void main(String[] args) {
        String str = "examplestring";

        // Step 1: Create a frequency map
        HashMap<Character, Integer> frequencyMap = new HashMap<>();

        for (char c : str.toCharArray()) {
            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
        }

        // Step 2: Convert the frequency map to a list of entries (Character, Frequency)
        List<Map.Entry<Character, Integer>> frequencyList = new ArrayList<>(frequencyMap.entrySet());

        // Step 3: Sort the list in descending order based on frequency
        Collections.sort(frequencyList, (a, b) -> b.getValue() - a.getValue());

        // Step 4: Print the sorted characters along with their frequencies
        System.out.println("Characters sorted by frequency (in descending order):");
        System.out.println(frequencyList.get(1));
        for (Map.Entry<Character, Integer> entry : frequencyList) {
           // System.out.println("Character: " + entry.getKey() + ", Frequency: " + entry.getValue());
      
    }
}
}