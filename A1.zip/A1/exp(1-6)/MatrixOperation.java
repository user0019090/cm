import java.util.Scanner;

public class MatrixOperation {
    public static int[][] strtomat(String PT, int k) {
        int length = PT.length();
        int rows = (int) Math.ceil((double) length / k); 
        int[][] matrix = new int[rows][k];
        
        // Initialize the matrix with 0s for empty spaces
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < k; j++) {
                matrix[i][j] = 0;
            }
        }

        // Fill the matrix with ASCII values of characters from the string
        for (int i = 0; i < length; i++) { 
            int row = i / k;
            int col = i % k;
            matrix[row][col] = PT.charAt(i); // Storing ASCII value
        }
        return matrix;
    }

    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in); 
        System.out.print("Enter the string: ");
        String PT = sc.nextLine();
        System.out.print("Enter the number of columns: "); 
        int k = sc.nextInt();

        int[][] matrix = strtomat(PT, k); 
        System.out.println("The matrix is:"); 
        for (int[] row : matrix) {
            for (int val : row) {
                // Print characters or spaces if ASCII value is 0
                System.out.print(val == 0 ? " " : (char) val);
            }
            System.out.println();
        }
        sc.close();
    }
}
