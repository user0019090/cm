def caesar_cipher_decrypt(ciphertext, shift):
    plaintext = ""
    for char in ciphertext:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            shifted_char = chr((ord(char) - shift_base - shift + 26) % 26 + shift_base)
            plaintext += shifted_char
        else:
            plaintext += char
    return plaintext

def frequency_analysis_attack(ciphertext):
    # Known frequency order of letters in English (case-insensitive)
    known_frequencies = ['E', 'T', 'A', 'O', 'I', 'N', 'S', 'H', 'R', 'D', 'L', 'C', 'U', 'M', 'W', 'F', 'G', 'Y', 'P', 'B', 'V', 'K', 'J', 'X', 'Q', 'Z']
    
    # Calculate the frequency of each letter in the ciphertext (case-insensitive)
    letter_counts = {}
    for char in ciphertext:
        if char.isalpha():
            char = char.upper()
            letter_counts[char] = letter_counts.get(char, 0) + 1

    # Sort letters by frequency
    sorted_ciphertext_letters = sorted(letter_counts, key=letter_counts.get, reverse=True)
    
    # Try possible shifts by matching most frequent letters
    for possible_most_frequent_letter in sorted_ciphertext_letters:
        for possible_known_letter in known_frequencies:
            shift = (ord(possible_most_frequent_letter) - ord(possible_known_letter)) % 26
            decrypted_text = caesar_cipher_decrypt(ciphertext, shift)
            print(f"Trying shift {shift} ({possible_most_frequent_letter} -> {possible_known_letter}): {decrypted_text}")
            # Add your own logic to determine if the decrypted_text makes sense
            # For this example, we assume the user can identify if it makes sense
            if input("Does this make sense? (y/n): ").lower() == 'y':
                return decrypted_text
    
    return "No valid plaintext found"

# Get user input
ciphertext = input("Enter the ciphertext: ")

# Perform frequency analysis attack
plaintext = frequency_analysis_attack(ciphertext)
print("Plaintext:", plaintext)

