import java.util.Scanner;

class MatrixOpS {
    // Function to calculate the determinant of a submatrix excluding given row and column
    public static int[][] submatrix(int[][] matrix, int excluding_row, int excluding_col, int n) {
        int[][] sub = new int[n - 1][n - 1];
        int row = 0, col = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != excluding_row && j != excluding_col) {
                    sub[row][col++] = matrix[i][j];
                    if (col == n - 1) {
                        col = 0;
                        row++;
                    }
                }
            }
        }
        return sub;
    }

    // Function to calculate the determinant of a matrix
    public static int determinant(int[][] matrix, int n) {
        if (n == 1) {
            return matrix[0][0];
        }
        if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }
        int det = 0;
        int sign = 1;
        for (int i = 0; i < n; i++) {
            int[][] sub = submatrix(matrix, 0, i, n);
            det += sign * matrix[0][i] * determinant(sub, n - 1);
            sign = -sign;
        }
        return det;
    }

    // Function to calculate the cofactor matrix of a matrix
    public static int[][] cofactor(int[][] matrix, int n) {
        int[][] cofactorMatrix = new int[n][n];
        int sign;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int[][] sub = submatrix(matrix, i, j, n);
                sign = (i + j) % 2 == 0 ? 1 : -1;
                cofactorMatrix[i][j] = sign * determinant(sub, n - 1);
            }
        }
        return cofactorMatrix;
    }

    // Function to transpose a matrix
    public static int[][] transpose(int[][] matrix, int n) {
        int[][] transposeMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                transposeMatrix[j][i] = matrix[i][j];
            }
        }
        return transposeMatrix;
    }

    // Function to find the adjoint of a matrix
    public static int[][] adjoint(int[][] matrix) {
        int n = matrix.length;
        int[][] cofactorMatrix = cofactor(matrix, n);
        int[][] adjointMatrix = transpose(cofactorMatrix, n);
        return adjointMatrix;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input for matrix size (assuming it's a square matrix)
        System.out.print("Enter the size of the square matrix (n): ");
        int n = scanner.nextInt();
        
        // Input for matrix elements
        int[][] matrix = new int[n][n];
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }
        
        // Calculate adjoint matrix
        int[][] adjointMatrix = adjoint(matrix);
        
        // Print the adjoint matrix
        System.out.println("Adjoint matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(adjointMatrix[i][j] + " ");
            }
            System.out.println();
        }
        
        scanner.close();
    }
}

