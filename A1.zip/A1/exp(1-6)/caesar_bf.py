def caesar_cipher_decrypt(ciphertext, shift):
    plaintext = ""
    for char in ciphertext:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            shifted_char = chr((ord(char) - shift_base - shift + 26) % 26 + shift_base)
            plaintext += shifted_char
        else:
            plaintext += char
    return plaintext

def brute_force_caesar_cipher(ciphertext):
    for shift in range(1, 26):
        plaintext = caesar_cipher_decrypt(ciphertext, shift)
        print(f"Shift {shift}: {plaintext}")

# Get user input
ciphertext = input("Enter the ciphertext: ")

# Perform brute force attack
brute_force_caesar_cipher(ciphertext)
