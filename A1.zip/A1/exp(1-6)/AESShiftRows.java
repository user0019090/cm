public class AESShiftRows {

    public static void main(String[] args) {
        // Example 4x4 state matrix for AES (in hexadecimal)
        int[][] state = {
            {0x00, 0x11, 0x22, 0x33},
            {0x44, 0x55, 0x66, 0x77},
            {0x88, 0x99, 0xaa, 0xbb},
            {0xcc, 0xdd, 0xee, 0xff}
        };

        // Perform the ShiftRows transformation
        shiftRows(state);

        // Print the result
        printState(state);
    }

    // ShiftRows operation for AES
    public static void shiftRows(int[][] state) {
        // Row 0 remains unchanged
        // Row 1 is shifted left by 1 byte
        state[1] = shiftLeft(state[1], 1);
        
        // Row 2 is shifted left by 2 bytes
        state[2] = shiftLeft(state[2], 2);
        
        // Row 3 is shifted left by 3 bytes (equivalent to right shift by 1 byte)
        state[3] = shiftLeft(state[3], 3);
    }

    // Helper function to shift a row to the left by n positions
    private static int[] shiftLeft(int[] row, int n) {
        int[] shiftedRow = new int[4];
        for (int i = 0; i < 4; i++) {
            shiftedRow[i] = row[(i + n) % 4];
        }
        return shiftedRow;
    }

    // Helper function to print the state matrix
    public static void printState(int[][] state) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(String.format("%02x ", state[i][j]));
            }
            System.out.println();
        }
    }
}