import java.util.Scanner;

class MatrixDeterminant {
    public static int matdet(int a[][], int p, int q) {
        if (p != q) {
            throw new IllegalArgumentException("Matrix must be square (p must equal q) to calculate determinant.");
        }
        
        // Base case for 1x1 matrix
        if (p == 1) {
            return a[0][0];
        }
        
        // Base case for 2x2 matrix
        if (p == 2) {
            return a[0][0] * a[1][1] - a[0][1] * a[1][0];
        }
        
        // Recursive case for larger matrices
        int determinant = 0;
        int sign = 1; // To alternate signs
        
        for (int col = 0; col < q; col++) {
            int[][] submatrix = new int[p - 1][q - 1];
            
            // Create submatrix excluding current row and column
            for (int i = 1; i < p; i++) {
                int submatrixCol = 0;
                for (int j = 0; j < q; j++) {
                    if (j == col) {
                        continue;
                    }
                    submatrix[i - 1][submatrixCol++] = a[i][j];
                }
            }
            
            // Recursive call to get determinant of submatrix
            int submatrixDeterminant = matdet(submatrix, p - 1, q - 1);
            
            // Add current element's contribution to determinant
            determinant += sign * a[0][col] * submatrixDeterminant;
            
            // Flip the sign for the next iteration
            sign = -sign;
        }
        
        return determinant;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input for matrix size
        System.out.print("Enter the size of the square matrix (n x n): ");
        int n = scanner.nextInt();
        
        // Input for matrix elements
        int[][] matrix = new int[n][n];
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }
        
        // Calculate determinant
        int determinant = matdet(matrix, n, n);
        
        // Print the determinant
        System.out.println("Determinant of the matrix:");
        System.out.println(determinant);
        
        scanner.close();
    }
}
