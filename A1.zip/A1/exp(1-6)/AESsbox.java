import java.util.Scanner;

public class AESsbox {
    private static final int Nb = 4; // Number of columns (32-bit words) comprising the State. For AES, Nb is always 4.
    private static final int Nk = 4; // Number of 32-bit words comprising the Cipher Key. For AES-128, Nk is 4.
    private static final int Nr = 10; // Number of rounds. For AES-128, Nr is 10.

    private static final int[] Rcon = {
        0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36
    };

    private static final int[] Sbox = {
        // Reduced S-box (only 10 values repeated)
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01
    };

    public static void main(String[] args) {
        byte[] key = getKeyFromUser();

        // Ensure the key is exactly 16 bytes (128 bits)
        if (key.length != 16) {
            throw new IllegalArgumentException("The key must be exactly 16 bytes (128 bits) long.");
        }

        byte[][] expandedKey = keyExpansion(key);
        printExpandedKeys(expandedKey);
    }

    private static byte[] getKeyFromUser() {
        Scanner scanner = new Scanner(System.in);
        byte[] key = new byte[16];

        System.out.println("Enter a 128-bit key as 16 hex bytes:");

        try {
            String input = scanner.nextLine().trim();
            if (input.length() != 32) {
                throw new IllegalArgumentException("Input must be exactly 32 hexadecimal characters.");
            }

            for (int i = 0; i < 16; i++) {
                String hexByte = input.substring(2 * i, 2 * i + 2);
                key[i] = (byte) Integer.parseInt(hexByte, 16);
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid hexadecimal input. Please ensure your input contains valid hex characters.");
        } finally {
            scanner.close();
        }

        return key;
    }

    public static byte[][] keyExpansion(byte[] key) {
        byte[][] w = new byte[Nb * (Nr + 1)][4];
        byte[] temp = new byte[4];

        // Initialize the first Nk words of w with the cipher key
        for (int i = 0; i < Nk; i++) {
            w[i][0] = key[4 * i];
            w[i][1] = key[4 * i + 1];
            w[i][2] = key[4 * i + 2];
            w[i][3] = key[4 * i + 3];
        }

        for (int i = Nk; i < Nb * (Nr + 1); i++) {
            System.arraycopy(w[i - 1], 0, temp, 0, 4);

            if (i % Nk == 0) {
                temp = subWord(rotWord(temp));
                temp[0] = (byte) (temp[0] ^ Rcon[(i / Nk) - 1]);
            } else if (Nk > 6 && (i % Nk == 4)) {
                temp = subWord(temp);
            }

            for (int j = 0; j < 4; j++) {
                w[i][j] = (byte) (w[i - Nk][j] ^ temp[j]);
            }
        }

        return w;
    }

    private static byte[] subWord(byte[] word) {
        for (int i = 0; i < 4; i++) {
            // Map the byte to the reduced S-box values
            word[i] = (byte) Sbox[(word[i] & 0xFF) % Sbox.length];
        }
        return word;
    }

    private static byte[] rotWord(byte[] word) {
        byte temp = word[0];
        System.arraycopy(word, 1, word, 0, 3);
        word[3] = temp;
        return word;
    }

    private static void printExpandedKeys(byte[][] expandedKey) {
        for (int round = 0; round <= Nr; round++) {
            System.out.println("Round " + round + " Key:");
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 4; col++) {
                    System.out.printf("%02X ", expandedKey[round * 4 + col][row]);
                }
                System.out.println();
            }
            System.out.println();
        }
    }
}
