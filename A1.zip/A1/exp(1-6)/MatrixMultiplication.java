import java.util.Scanner;

class MatrixMultiplication {
    public static int[][] matmul(int a[][], int b[][], int p, int q, int r, int s) {
        // Check if matrix dimensions are valid for multiplication
        if (q != r) {
            System.out.println("Matrix dimensions are not compatible for multiplication.");
            return 0;
        }
        
        // Initialize result matrix with dimensions p x s
        int[][] result = new int[p][s];
        
        // Perform matrix multiplication
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < s; j++) {
                int sum = 0;
                for (int k = 0; k < q; k++) {
                    sum += a[i][k] * b[k][j];
                }
                result[i][j] = sum;
            }
        }
        
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input for matrix a
        System.out.print("Enter the number of rows in matrix A: ");
        int p = scanner.nextInt();
        System.out.print("Enter the number of columns in matrix A: ");
        int q = scanner.nextInt();
        
        int[][] a = new int[p][q];
        System.out.println("Enter the elements of matrix A:");
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                a[i][j] = scanner.nextInt();
            }
        }
        
        // Input for matrix b
        System.out.print("Enter the number of rows in matrix B: ");
        int r = scanner.nextInt();
        System.out.print("Enter the number of columns in matrix B: ");
        int s = scanner.nextInt();
        
        int[][] b = new int[r][s];
        System.out.println("Enter the elements of matrix B:");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < s; j++) {
                b[i][j] = scanner.nextInt();
            }
        }
        
        // Perform matrix multiplication
        int[][] result = matmul(a, b, p, q, r, s);
        
        // Print the result matrix
        if (result != null) {
            System.out.println("Result of matrix multiplication:");
            for (int i = 0; i < p; i++) {
                for (int j = 0; j < s; j++) {
                    System.out.print(result[i][j] + " ");
                }
                System.out.println();
            }
        }

        scanner.close();
    }
}
