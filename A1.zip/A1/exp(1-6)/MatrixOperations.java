
import java.util.Scanner;

class MatrixOperations {
    public static int[][] scalmul(int a[][], int p, int q, int detkeyinv, int m) {
        int[][] result = new int[p][q];
        
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                result[i][j] = a[i][j] * detkeyinv;
                
                // Apply modulo operation if m is provided
                if (m > 0) {
                    result[i][j] = (result[i][j] % m + m) % m; // Ensure result is non-negative
                }
            }
        }
        
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input for matrix size
        System.out.print("Enter the number of rows in the matrix: ");
        int p = scanner.nextInt();
        System.out.print("Enter the number of columns in the matrix: ");
        int q = scanner.nextInt();
        
        // Input for matrix elements
        int[][] matrix = new int[p][q];
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }
        
        // Input for scalar multiplier
        System.out.print("Enter the scalar multiplier: ");
        int detkeyinv = scanner.nextInt();
        
        // Input for modulo value (optional)
        System.out.print("Enter the modulo value (enter 0 if no modulo operation): ");
        int m = scanner.nextInt();
        
        // Perform scalar multiplication
        int[][] result = scalmul(matrix, p, q, detkeyinv, m);
        
        // Print the resulting matrix
        System.out.println("Result after scalar multiplication:");
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
        
        scanner.close();
    }
}
