def caesar_cipher_decrypt(ciphertext, shift):
    plaintext = ""
    for char in ciphertext:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            shifted_char = chr((ord(char) - shift_base - shift + 26) % 26 + shift_base)
            plaintext += shifted_char
        else:
            plaintext += char
    return plaintext

# Get user input
ciphertext = input("Enter the text you want to decrypt: ")
shift = int(input("Enter the shift key (number): "))

# Decrypt the ciphertext
plaintext = caesar_cipher_decrypt(ciphertext, shift)

# Output the plaintext
print("Plaintext:", plaintext)
