import java.util.Scanner;

public class HillCipher {
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Encrypt");
            System.out.println("2. Decrypt");
            System.out.println("3. Known Plaintext Attack");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    performEncryption(scanner);
                    break;
                case 2:
                    performDecryption(scanner);
                    break;
                case 3:
                    performKnownPlaintextAttack(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, 3, or 4.");
                    break;
            }
        } while (choice != 4);
        scanner.close();
    }

    private static void performEncryption(Scanner scanner) {
        System.out.println("\nEncryption.......");
        System.out.print("Enter key size (order of key matrix): ");
        int keySize = scanner.nextInt();
        int[][] keyMatrix = getKeyMatrix(scanner, keySize);
        System.out.print("Enter plaintext: ");
        scanner.nextLine();
        String plaintext = scanner.nextLine().toLowerCase().replaceAll("[^a-z]", "");
        int[][] plainTextMatrix = stringToMatrix(plaintext, keySize);
        System.out.println("Plaintext Matrix:");
        printMatrix(plainTextMatrix);
        int[][] cipherTextMatrix = matmul(keyMatrix, plainTextMatrix, keySize, keySize, plainTextMatrix.length, plainTextMatrix[0].length, 26);
        String cipherText = mattostr(cipherTextMatrix, keySize, plainTextMatrix[0].length);
        System.out.println("Cipher Text: " + cipherText);
    }

    private static void performDecryption(Scanner scanner) {
        System.out.println("\nDecryption........");
        System.out.print("Enter key size (order of key matrix): ");
        int keySize = scanner.nextInt();
        int[][] keyMatrix = getKeyMatrix(scanner, keySize);
        System.out.print("Enter ciphertext: ");
        scanner.nextLine();
        String ciphertext = scanner.nextLine().toLowerCase().replaceAll("[^a-z]", "");
        int[][] cipherTextMatrix = stringToMatrix(ciphertext, keySize);
        System.out.println("Ciphertext Matrix:");
        printMatrix(cipherTextMatrix);
        int[][] inverseKeyMatrix = inverse(keyMatrix, 26);
        if (inverseKeyMatrix == null) {
            System.out.println("Decryption failed: Key matrix is not invertible (determinant = 0 or has no inverse modulo 26)");
            return;
        }
        int[][] decryptedMatrix = matmul(inverseKeyMatrix, cipherTextMatrix, keySize, keySize, cipherTextMatrix.length, cipherTextMatrix[0].length, 26);
        String decryptedText = mattostr(decryptedMatrix, keySize, cipherTextMatrix[0].length);
        System.out.println("Decrypted Text: " + decryptedText);
    }

    private static void performKnownPlaintextAttack(Scanner scanner) {
        System.out.println("\nKnown Plaintext Attack........");
        System.out.print("Enter key size (order of key matrix): ");
        int keySize = scanner.nextInt();
        System.out.print("Enter known plaintext: ");
        scanner.nextLine();
        String plaintext = scanner.nextLine().toLowerCase().replaceAll("[^a-z]", "");
        System.out.print("Enter known ciphertext: ");
        String ciphertext = scanner.nextLine().toLowerCase().replaceAll("[^a-z]", "");
        int[][] plainTextMatrix = stringToMatrix(plaintext, keySize);
        int[][] cipherTextMatrix = stringToMatrix(ciphertext, keySize);
        System.out.println("Plaintext Matrix:");
        printMatrix(plainTextMatrix);
        System.out.println("Ciphertext Matrix:");
        printMatrix(cipherTextMatrix);
        int[][] inversePlainTextMatrix = inverse(plainTextMatrix, 26);
        if (inversePlainTextMatrix == null) {
            System.out.println("Attack failed: Plaintext matrix is not invertible (determinant = 0 or has no inverse modulo 26)");
            return;
        }
        int[][] keyMatrix = matmul(cipherTextMatrix, inversePlainTextMatrix, keySize, keySize, inversePlainTextMatrix.length, inversePlainTextMatrix[0].length, 26);
        System.out.println("Recovered Key Matrix:");
        printMatrix(keyMatrix);
        System.out.print("Enter ciphertext to decrypt using the recovered key: ");
        String newCiphertext = scanner.nextLine().toLowerCase().replaceAll("[^a-z]", "");
        int[][] newCipherTextMatrix = stringToMatrix(newCiphertext, keySize);
        int[][] inverseRecoveredKeyMatrix = inverse(keyMatrix, 26);
        if (inverseRecoveredKeyMatrix == null) {
            System.out.println("Decryption failed: Recovered key matrix is not invertible (determinant = 0 or has no inverse modulo 26)");
            return;
        }
        int[][] decryptedMatrix = matmul(inverseRecoveredKeyMatrix, newCipherTextMatrix, keySize, keySize, newCipherTextMatrix.length, newCipherTextMatrix[0].length, 26);
        String decryptedText = mattostr(decryptedMatrix, keySize, newCipherTextMatrix[0].length);
        System.out.println("Decrypted Text: " + decryptedText);
    }

    public static int[][] stringToMatrix(String text, int keyOrder) {
        int textLength = text.length();
        int filler = ALPHABET.indexOf('x');
        int columns = (int) Math.ceil((double) textLength / keyOrder);
        int[][] matrix = new int[keyOrder][columns];
        int index = 0;
        for (int col = 0; col < columns; col++) {
            for (int row = 0; row < keyOrder; row++) {
                if (index < textLength) {
                    char ch = text.charAt(index);
                    int charIndex = ALPHABET.indexOf(ch);
                    if (charIndex != -1) {
                        matrix[row][col] = charIndex;
                    } else {
                        matrix[row][col] = filler;
                    }
                } else {
                    matrix[row][col] = filler;
                }
                index++;
            }
        }
        return matrix;
    }

    public static int[][] matmul(int[][] a, int[][] b, int p, int q, int r, int s, int m) {
        int[][] result = new int[p][s];
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < s; j++) {
                result[i][j] = 0;
                for (int k = 0; k < q; k++) {
                    result[i][j] = (result[i][j] + a[i][k] * b[k][j]) % m;
                }
                result[i][j] = (result[i][j] + m) % m;
            }
        }
        return result;
    }

    public static int[][] inverse(int[][] matrix, int m) {
        int determinant = determinant(matrix, matrix.length) % m;
        if (determinant < 0) determinant += m;
        if (determinant == 0 || gcd(determinant, m) != 1) {
            return null;
        }
        int detInv = modInverse(determinant, m);
        int[][] adjointMatrix = adjoint(matrix);
        int[][] inverseMatrix = scalarmatrix(adjointMatrix, matrix.length, matrix.length, detInv, m);
        return inverseMatrix;
    }

    public static int determinant(int[][] matrix, int n) {
        int det = 0;
        if (n == 1) {
            return matrix[0][0];
        } else if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        } else {
            int sign = 1;
            for (int i = 0; i < n; i++) {
                int[][] submatrix = new int[n - 1][n - 1];
                for (int j = 1; j < n; j++) {
                    int submatrixCol = 0;
                    for (int k = 0; k < n; k++) {
                        if (k != i) {
                            submatrix[j - 1][submatrixCol++] = matrix[j][k];
                        }
                    }
                }
                det += sign * matrix[0][i] * determinant(submatrix, n - 1);
                sign = -sign;
            }
        }
        return det;
    }

    public static int modInverse(int a, int m) {
        int m0 = m, t, q;
        int x0 = 0, x1 = 1;
        if (m == 1) return 0;
        while (a > 1) {
            q = a / m;
            t = m;
            m = a % m;
            a = t;
            t = x0;
            x0 = x1 - q * x0;
            x1 = t;
        }
        if (x1 < 0) x1 += m0;
        return x1;
    }

    public static int[][] adjoint(int[][] matrix) {
        int n = matrix.length;
        int[][] adj = new int[n][n];
        if (n == 1) {
            adj[0][0] = 1;
            return adj;
        }
        int sign;
        int[][] temp = new int[n - 1][n - 1];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                getCofactor(matrix, temp, i, j, n);
                sign = ((i + j) % 2 == 0) ? 1 : -1;
                adj[j][i] = (sign * determinant(temp, n - 1)) % 26;
                if (adj[j][i] < 0) {
                    adj[j][i] += 26;
                }
            }
        }
        return adj;
    }

    public static void getCofactor(int[][] matrix, int[][] temp, int p, int q, int n) {
        int i = 0, j = 0;
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if (row != p && col != q) {
                    temp[i][j++] = matrix[row][col];
                    if (j == n - 1) {
                        j = 0;
                        i++;
                    }
                }
            }
        }
    }

    public static int[][] scalarmatrix(int[][] matrix, int p, int q, int s, int m) {
        int[][] result = new int[p][q];
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                result[i][j] = (matrix[i][j] * s) % m;
                if (result[i][j] < 0) {
                    result[i][j] += m;
                }
            }
        }
        return result;
    }

    public static String mattostr(int[][] mat, int p, int q) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < q; i++) {
            for (int j = 0; j < p; j++) {
                result.append(ALPHABET.charAt(mat[j][i]));
            }
        }
        return result.toString();
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
    }

    public static int[][] getKeyMatrix(Scanner scanner, int order) {
        int[][] keyMatrix = new int[order][order];
        System.out.println("Enter key matrix (row by row):");
        for (int i = 0; i < order; i++) {
            for (int j = 0; j < order; j++) {
                keyMatrix[i][j] = scanner.nextInt();
            }
        }
        return keyMatrix;
    }

    public static int gcd(int a, int b) {
        if (b == 0) return a;
        return gcd(b, a % b);
    }
}
