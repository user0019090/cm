import java.math.BigInteger;
import java.util.Scanner;

class RSA {
    private static BigInteger p, q, e, n, phi, d;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nRSA Encryption/Decryption Menu:");
            System.out.println("1. Generate Keys");
            System.out.println("2. Encrypt Message");
            System.out.println("3. Decrypt Message");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    generateKeys(sc);
                    break;
                case 2:
                    encryptMessage(sc);
                    break;
                case 3:
                    decryptMessage(sc);
                    break;
                case 4:
                    exit = true;
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Key generation method
    private static void generateKeys(Scanner sc) {
        System.out.println("Enter prime number p: ");
        p = sc.nextBigInteger();
        while (!p.isProbablePrime(100)) {
            System.out.println("p is not a prime number. Please enter a prime number for p: ");
            p = sc.nextBigInteger();
        }

        System.out.println("Enter prime number q: ");
        q = sc.nextBigInteger();
        while (!q.isProbablePrime(100)) {
            System.out.println("q is not a prime number. Please enter a prime number for q: ");
            q = sc.nextBigInteger();
        }

        System.out.println("Enter public exponent e: ");
        e = sc.nextBigInteger();

        n = p.multiply(q);
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        d = e.modInverse(phi); // Calculate d as the modular inverse of e mod phi

        System.out.println("Public Key (e, n): (" + e + ", " + n + ")");
        System.out.println("Private Key (d, n): (" + d + ", " + n + ")");
    }

    // Encryption method
    private static void encryptMessage(Scanner sc) {
        sc.nextLine(); // Consume newline left-over
        System.out.println("Enter the message to encrypt (A-Z): ");
        String message = sc.nextLine().toUpperCase();
        StringBuilder encryptedMessage = new StringBuilder();

        for (char character : message.toCharArray()) {
            int M = character - 'A'; // Convert character to its position in the alphabet (0-25)
            BigInteger MBig = BigInteger.valueOf(M);
            BigInteger C = repeatedSquaring(MBig, e, n); // Encrypt using RSA
            encryptedMessage.append(C).append(" "); // Append encrypted value
        }

        System.out.println("Encrypted message: " + encryptedMessage.toString().trim());
    }

    // Decryption method
    private static void decryptMessage(Scanner sc) {
        sc.nextLine(); // Consume newline left-over
        System.out.println("Enter the encrypted message (space-separated numbers): ");
        String encryptedMessage = sc.nextLine();
        String[] encryptedValues = encryptedMessage.trim().split(" ");
        StringBuilder decryptedMessage = new StringBuilder();

        for (String value : encryptedValues) {
            BigInteger C = new BigInteger(value);
            BigInteger decryptedValue = repeatedSquaring(C, d, n); // Decrypt using RSA
            char decryptedCharacter = (char) (decryptedValue.intValue() + 'A'); // Convert back to character (0-25 to A-Z)
            decryptedMessage.append(decryptedCharacter);
        }
        System.out.println("Decrypted message: " + decryptedMessage.toString());
    }

    // Repeated Squaring method using BigInteger
    static BigInteger repeatedSquaring(BigInteger a, BigInteger b, BigInteger m) {
        BigInteger res = BigInteger.ONE; // Initialize result as 1
        a = a.mod(m); // Update 'a' to be within the modulus

        while (b.compareTo(BigInteger.ZERO) > 0) {
            if (b.mod(BigInteger.valueOf(2)).equals(BigInteger.ONE)) {
                res = res.multiply(a).mod(m); // Multiply and mod if b is odd
            }
            a = a.multiply(a).mod(m); // Square 'a'
            b = b.divide(BigInteger.valueOf(2)); // Divide b by 2
        }
        return res;
    }
}
