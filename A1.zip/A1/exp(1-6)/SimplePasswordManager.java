import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
public class SimplePasswordManager {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Map<String, String> dictionaryMap = new HashMap<>();
    private static final Map<String, String> passwordTableMap = new HashMap<>();
    private static String charset = "";
  private static int passwordLength = 0;
   public static void main(String[] args) {
        while (true) {
            displayMenu();
            int choice = Integer.parseInt(scanner.nextLine());
            long startTime, endTime;
            switch (choice) {
                case 1:
                    // Create a dictionary and measure the execution time
                    startTime = System.nanoTime();
                    createDictionary();
                    endTime = System.nanoTime();
                    displayExecutionTime(startTime, endTime);
                    break;
                case 2:
                    // Create a password table and measure the execution time
                    startTime = System.nanoTime();
                    createPasswordTable();
                    endTime = System.nanoTime();
                    displayExecutionTime(startTime, endTime);
                    break;
                case 3:
                    // Launch dictionary attack and measure the execution time
                    startTime = System.nanoTime();
                    launchDictionaryAttack();
                    endTime = System.nanoTime();
                    displayExecutionTime(startTime, endTime);
                    break;
                case 4:
                    // Exit the application
                    System.exit(0);
                    break;
                default:
                    // Handle invalid choices
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
private static void displayMenu() {
        System.out.println("Main Menu");
        System.out.println("1: Create Dictionary");
        System.out.println("2: Create Password Table");
        System.out.println("3: Launch Dictionary Attack");
        System.out.println("4: Exit");
        System.out.print("Enter your choice: ");
    }
private static void createDictionary() {
        // Set character set and password length, then generate dictionary words
        setCharacterSet();
        setPasswordLength();
        dictionaryMap.clear(); // Clear any existing dictionary entries
        generateWords("", passwordLength); // Start generating words
    }
private static void setCharacterSet() {
        // Set the character set for generating dictionary words
        System.out.println("Set Character Set:");
        System.out.println("1: Alphabets (Lowercase/Uppercase)");
        System.out.println("2: Numeric");
        System.out.print("Enter your choice: ");
        int choice = Integer.parseInt(scanner.nextLine());
        switch (choice) {
            case 1:
                charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                break;
            case 2:
                charset = "0123456789";
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                setCharacterSet(); // Retry if input is invalid
        }
    }
private static void setPasswordLength() {
        // Set the length of passwords to be generated
        System.out.print("Enter password length: ");
        passwordLength = Integer.parseInt(scanner.nextLine());
    }
private static void generateWords(String prefix, int length) {
        // Recursively generate all possible combinations of characters
        if (length == 0) {
            dictionaryMap.put(prefix, prefix); // Add generated word to dictionary
            return;
        }
        for (char c : charset.toCharArray()) {
            generateWords(prefix + c, length - 1); // Recursive call with reduced length
        }
    }
private static void createPasswordTable() {
        // Create a password table for given usernames and passwords
        if (dictionaryMap.isEmpty()) {
            System.out.println("Dictionary is not created. Please create the dictionary first.");
            return;
        }
        passwordTableMap.clear(); // Clear any existing password entries
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            // Validate password length and character set
            if (password.length() != passwordLength || !password.matches("[" + charset + "]+")) {
                System.out.println("Password does not match the length or character set. Try again.");
                i--; // Retry for the same index
                continue;
            }
            String hashedPassword = hashPassword(password); // Hash the password
            passwordTableMap.put(username, hashedPassword); // Store the username and hashed password
        }
    }
private static void launchDictionaryAttack() {
        // Attempt to find the password for a given username using the dictionary
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        if (!passwordTableMap.containsKey(username)) {
            System.out.println("Username not found.");
            return;
        }
        String hashedPassword = passwordTableMap.get(username);
        // Check each dictionary entry to see if it matches the stored hashed password
        for (Map.Entry<String, String> entry : dictionaryMap.entrySet()) {
            if (hashPassword(entry.getValue()).equals(hashedPassword)) {
                System.out.println("Password found: " + entry.getValue());
                return;
            }
        }
        System.out.println("Password not found in dictionary.");
    }
private static String hashPassword(String password) {
        // Hash a password using SHA-256
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b)); // Convert each byte to hex
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e); // Handle error if SHA-256 is not available
        }
    }
private static void displayExecutionTime(long startTime, long endTime) {
        // Display the time taken for the operation in milliseconds
        long duration = endTime - startTime;
        System.out.println("Execution time: " + TimeUnit.NANOSECONDS.toMillis(duration) + " ms");
    }
}
