
import java.util.Scanner;

class ModInverse {
    // Function to compute the GCD of two numbers
    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Function to compute the modular multiplicative inverse
    public static int mulinv(int a, int b) {
        if (gcd(a, b) != 1) {
            throw new ArithmeticException("No inverse exists");
        }

        int b0 = b, t, q;
        int x0 = 0, x1 = 1;
        if (b == 1) return 1;
        while (a > 1) {
            q = a / b;
            t = b;
            b = a % b;
            a = t;
            t = x0;
            x0 = x1 - q * x0;
            x1 = t;
        }
        if (x1 < 0) x1 += b0;
        return x1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the value of a: ");
        int a = scanner.nextInt();

        System.out.print("Enter the value of b: ");
        int b = scanner.nextInt();

        try {
            int inverse = mulinv(a, b);
            System.out.println("The modular multiplicative inverse of " + a + " modulo " + b + " is " + inverse);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }

        scanner.close();
    }
}
